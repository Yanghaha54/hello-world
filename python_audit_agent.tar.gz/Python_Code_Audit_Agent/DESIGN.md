# Python Code Audit Agent — 架构设计文档

## 设计目标

构建基于 Claude Agent 工作流的 Python Web 代码安全审计系统，目标代码量 10-50MB，覆盖 Django / Flask / FastAPI 及通用 Python Web 项目。

## 核心挑战与解决方案

| 挑战 | 解决方案 |
|------|----------|
| 10-50MB 代码无法塞入 LLM 上下文 | AST 预处理 + 代码索引 + 精准上下文窗口 |
| 跨文件数据流追踪 | 构建 Call Graph + 模块依赖图 |
| 误报率高 | 多阶段流水线：Scan → Audit → Review |
| 多种漏洞类型 | 每种漏洞独立 Skill，可插拔 |

## 审计流水线（7 阶段）

```
Phase 1: Indexing          Phase 1.5: Endpoint       Phase 2: Source/Sink
  遍历 .py 文件             提取 HTTP 路由装饰器         识别用户输入入口点
  AST 解析                  解析 urlpatterns            识别危险函数调用
  构建 Call Graph           映射 handler + HTTP 方法    识别过滤/校验函数
  复杂度评分                 标注认证要求                 关联到 endpoint_id
  端点 hints                 输出 endpoints.json

     ↓                          ↓                          ↓
Phase 3: Dataflow          Phase 4: LLM Deep Audit   Phase 5: Review
  Source → Sink 追踪        构建端点感知上下文           去重合并
  关联到 endpoint            语义级漏洞分析              降误报
  覆盖率快照                 追踪审计进度                关联分析
  端点风险摘要               输出 confirmed_vulns        **覆盖率质量审查**

     ↓                          ↓                          ↓
                        Phase 6: Report
                          按严重程度排序
                          **端点审计清单**
                          **覆盖率分析**
                          修复路线图
                          Markdown 输出
```

## Agent 协作模型

```
用户触发 /python_audit 或 /python_full_scan
         │
         ▼
   ┌─────────────┐
   │ Scan Agent  │ ─── 运行 code-scanner + endpoint_scanner skill
   │ (扫描阶段)   │     输出：risk_entries.json + endpoints.json + coverage baseline
   └──────┬──────┘
          │ risk_entries[] + endpoints[] + coverage snapshot
          ▼
   ┌──────────────┐
   │ Audit Agent  │ ─── 对每个 risk_entry (端点感知 + 覆盖率追踪)
   │ (审计阶段)    │     输出：confirmed_vulns.json + audit_coverage.json
   └──────┬───────┘
          │ confirmed_vulns[] + audit_coverage.json
          ▼
   ┌───────────────┐
   │ Review Agent  │ ─── 去重、降误报、关联分析、覆盖率质量审查
   │ (复核阶段)     │     输出：final_vulns.json (含 coverage_analysis)
   └──────┬────────┘
          │ final_vulns[] (含 coverage)
          ▼
   ┌──────────────┐
   │ Report Agent │ ─── 调用 report-generator skill
   │ (报告阶段)    │     输出：audit-report.md (含端点清单 + 覆盖率分析)
   └──────────────┘
```

## 上下文管理策略

### 1. 代码索引（本地 AST，不消耗 LLM token）
遍历项目，提取每个文件的函数/类签名 + 导入关系，生成轻量级索引。

### 2. Source/Sink 识别（规则匹配，不消耗 LLM token）
基于注册表匹配危险函数和用户输入入口点。

### 3. 优先级排序
- 包含 eval/exec/system/execute 等高风险关键字的文件优先
- 路由处理函数优先（views.py、api.py）
- 近期修改的文件优先

### 4. 精准上下文窗口
对每个潜在漏洞，只提取：
- Source 代码块（用户输入入口）
- 数据流路径（变量传递链）
- Sink 代码块（危险函数调用）
- 关联的 Sanitizer（过滤/校验）

单次审计上下文控制在 2000 行以内。

### 5. 分批处理
按模块/目录分批，每批结果独立分析后汇总。

## 外部接口枚举 (Phase 1.5)

确保项目的所有 HTTP 端点都被识别和审计，防止遗漏攻击面。

**检测范围**: Django urlpatterns / Flask route 装饰器 / FastAPI 路由装饰器 / DRF @action

**每个端点记录**: 唯一 ID、HTTP 方法、URL 路径、handler 位置、认证要求、关联 source/sink、审计状态 (pending → audited → skipped)

输出 `endpoints.json` 作为外部接口完整清单。

## 覆盖率保障机制

| 层级 | 度量 | 目标 |
|------|------|------|
| AST 扫描覆盖 | scanned_files / total_files | 所有 .py 文件 |
| 风险发现覆盖 | files_with_risk / scanned_files | 标记所有潜在风险 |
| LLM 审计覆盖 | audited_files / files_with_risk | ≥ 80% 必须 LLM 审计 |
| 端点审计覆盖 | audited_endpoints / total_endpoints | ≥ 80%，公开端点 100% |

**防漏机制**:
1. 每个 source/sink 关联 endpoint_id，确保端点可追溯
2. 跳过的条目必须记录跳过原因
3. 高复杂度文件 (> 20) 即使无 risk_entry 也标记为盲区
4. Phase 5 覆盖率质量审查，不达标则标记 warning

## 漏洞覆盖矩阵

### SQL 注入 (sqli)
- **Django**: cursor.execute(), RawSQL(), extra(), Manager.raw()
- **Flask**: cursor.execute(), db.session.execute()
- **FastAPI**: conn.execute(), Session.execute(), text()
- **通用**: sqlite3.execute(), psycopg2.execute(), mysql.execute()

### 跨站脚本 (xss)
- **Django**: mark_safe(), |safe filter, @html_safe, format_html()
- **Flask**: render_template_string(), Markup()
- **FastAPI**: HTMLResponse()
- **通用**: print() to HTML, StringIO in web context

### 命令注入 (cmdi)
- **通用**: os.system(), os.popen(), subprocess.call(shell=True), subprocess.Popen(shell=True)
- **危险**: eval(), exec(), compile(), __import__()

### SSRF (ssrf)
- **通用**: requests.get(), urllib.request.urlopen(), httpx.get(), aiohttp.ClientSession().get()

### 反序列化 (deserialize)
- **通用**: pickle.load()/loads(), yaml.load() (not safe_load), marshal.loads(), dill.loads()

### 权限绕过 (authz)
- **Django**: @login_required 缺失, @permission_required 缺失
- **Flask**: @login_required 缺失, before_request 绕过
- **FastAPI**: Depends(get_current_user) 缺失

### 任意文件读取 (file-read)
- **Django**: FileSystemStorage, FileResponse, open(user_path)
- **Flask**: send_file(user_path), send_from_directory(user_path)
- **FastAPI**: FileResponse(user_path)
- **通用**: open(user_controlled_path), Path.read_text()

### 文件上传 (file-upload)
- **Django**: FileField, ImageField 无类型校验
- **Flask**: request.files, file.save()
- **FastAPI**: UploadFile

### 敏感信息泄露 (info-leak)
- Django DEBUG=True
- SECRET_KEY/API_KEY 硬编码
- 详细的错误页面 / traceback
- 敏感配置暴露

### XXE (xxe)
- **通用**: lxml.etree.parse(), xml.etree.ElementTree, defusedxml 缺失

### 依赖库 CVE (cve-scanner)
- requirements.txt 中已知漏洞版本
- Pipfile/Pipfile.lock 依赖版本

## 风险评分体系

| 严重程度 | 分数 | 条件 |
|---------|------|------|
| Critical | 9-10 | 无需认证即可 RCE / 数据泄露 |
| High | 7-8 | 需要认证但可提权 / SSRF / SQLi |
| Medium | 4-6 | XSS / 信息泄露 / 需特定条件 |
| Low | 1-3 | 配置不当 / 废弃依赖 |
| Info | 0 | 代码质量建议 |

## 扩展性设计

1. **新漏洞类型**: 在 skills/vulns/ 下新建目录并添加 SKILL.md 即可
2. **新框架支持**: 更新 config/ 下的 source/sink 注册表
3. **自定义报告**: 修改 report-generator 的模板
4. **CVE 数据源**: 可接入 safety / pip-audit / OSV API

## 验证方法

1. 使用 tests/fixtures/ 下的漏洞代码样本验证检出能力
2. 用已知漏洞的开源项目做端到端测试
3. 对比人工审计结果，计算检出率和误报率
