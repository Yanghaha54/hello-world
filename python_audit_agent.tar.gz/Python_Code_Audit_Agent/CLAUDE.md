# Python Code Audit Agent

基于 Claude Agent 工作流的 Python Web 安全代码审计系统。

## 核心能力

针对 10-50MB 规模的 Python Web 项目，提供：
- **静态分析**: AST 解析 + Source/Sink 识别 + 数据流追踪 + 端点枚举
- **LLM 深度审计**: Claude 对高风险代码路径进行语义级漏洞分析
- **多框架覆盖**: Django / Flask / FastAPI / 通用 Python Web
- **漏洞覆盖**: OWASP Top 10 + 业务逻辑漏洞 + CVE 依赖扫描 + 敏感信息泄露
- **外部接口跟踪**: 100% 端点审计覆盖率保障
- **代码覆盖保障**: 防 AI 偷懒，强制追踪审计盲区

## 使用方法

```
/python_audit <path>        # 定向审计指定目录或文件
/python_full_scan            # 全量扫描，运行完整 7 阶段流水线（含端点枚举 + 覆盖率检查）
/python_risk_score           # 快速风险评分，不深度分析
```

## 工作流程

```
扫描 (Scan Agent) → 审计 (Audit Agent) → 复核 (Review Agent) → 报告 (Report Agent)
```

## 项目结构

```
Python_Code_Audit_Agent/
├── CLAUDE.md                 # 本文件
├── DESIGN.md                 # 架构设计文档
├── setup.sh                  # 环境初始化脚本
├── agents/                   # Agent 定义 (4 个)
├── commands/                 # 用户命令 (3 个)
├── skills/                   # 技能模块
│   ├── code-scanner/         # 扫描基础设施
│   ├── vulns/                # 漏洞检测技能 (10 种)
│   └── report-generator/     # 报告生成
├── config/                   # 配置文件
└── tests/                    # 测试用例
```

## 配置

- `config/risk-weights.yaml` — 风险权重配置
- `config/scan-config.yaml` — 扫描行为配置

## 依赖

- Python 3.10+
- Claude API access
- 可选: bandit, safety (CVE 扫描增强)
