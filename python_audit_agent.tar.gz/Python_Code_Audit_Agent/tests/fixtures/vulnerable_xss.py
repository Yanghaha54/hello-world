"""
Test Fixture: XSS vulnerabilities
"""
from django.http import HttpResponse
from django.utils.safestring import mark_safe
from django.utils.html import format_html
from flask import Flask, render_template_string, Markup

app = Flask(__name__)


# --- Django XSS ---

def django_unsafe_render(request):
    """VULN: mark_safe on user input"""
    user_bio = request.GET.get("bio", "")
    safe_html = mark_safe(f"<div class='bio'>{user_bio}</div>")
    return HttpResponse(safe_html)


def django_format_html_unsafe(request):
    """VULN: format_html with mark_safe user input"""
    user_input = request.GET.get("content", "")
    html = format_html("<div>{}</div>", mark_safe(user_input))
    return HttpResponse(html)


def django_safe_render(request):
    """SAFE: Django template auto-escaped"""
    user_bio = request.GET.get("bio", "")
    return HttpResponse(f"<div>{user_bio}</div>")  # 模板自动转义


# --- Flask XSS ---

@app.route("/greet")
def greet():
    """VULN: render_template_string with user input (also SSTI risk)"""
    name = request.args.get("name", "Guest")
    return render_template_string(f"<h1>Hello {name}</h1>")


@app.route("/markup")
def markup_view():
    """VULN: Markup() on user input"""
    content = request.args.get("content", "")
    return Markup(f"<div>{content}</div>")


@app.route("/safe-greet")
def safe_greet():
    """SAFE: render_template with autoescape"""
    name = request.args.get("name", "Guest")
    return render_template_string("<h1>Hello {{ name }}</h1>", name=name)
