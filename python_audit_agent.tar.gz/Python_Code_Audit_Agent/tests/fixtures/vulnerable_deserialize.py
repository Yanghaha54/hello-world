"""
Test Fixture: Deserialization vulnerabilities
"""
import pickle
import yaml
import json
from flask import Flask, request, jsonify

app = Flask(__name__)


@app.route("/load-data", methods=["POST"])
def load_data():
    """VULN: pickle.loads on user data"""
    data = request.get_data()
    obj = pickle.loads(data)
    return jsonify({"type": str(type(obj))})


@app.route("/load-yaml", methods=["POST"])
def load_yaml():
    """VULN: yaml.load (unsafe) on user data"""
    yaml_data = request.get_data()
    obj = yaml.load(yaml_data)
    return jsonify({"data": obj})


@app.route("/load-config", methods=["POST"])
def load_config():
    """VULN: yaml.full_load on user data"""
    yaml_data = request.get_data()
    config = yaml.full_load(yaml_data)
    return jsonify({"config": config})


@app.route("/safe-yaml", methods=["POST"])
def safe_yaml():
    """SAFE: yaml.safe_load"""
    yaml_data = request.get_data()
    obj = yaml.safe_load(yaml_data)
    return jsonify({"data": obj})


@app.route("/safe-json", methods=["POST"])
def safe_json():
    """SAFE: json.loads (not pickle)"""
    json_data = request.get_data()
    obj = json.loads(json_data)
    return jsonify({"data": obj})
