"""
Test Fixture: Flask Command Injection vulnerabilities
"""
import os
import subprocess
from flask import Flask, request, jsonify

app = Flask(__name__)


@app.route("/ping")
def ping():
    """VULN: Command injection via os.system"""
    host = request.args.get("host", "127.0.0.1")
    os.system(f"ping -c 1 {host}")
    return jsonify({"status": "ok"})


@app.route("/exec")
def exec_cmd():
    """VULN: Command injection via subprocess with shell=True"""
    cmd = request.args.get("cmd")
    output = subprocess.check_output(cmd, shell=True)
    return jsonify({"output": output.decode()})


@app.route("/convert")
def convert():
    """VULN: Command injection via list-form subprocess with controllable args"""
    filename = request.args.get("file")
    result = subprocess.run(["convert", filename, "-resize", "100x100", "out.jpg"],
                            capture_output=True)
    return jsonify({"status": "done"})


@app.route("/safe-ping")
def safe_ping():
    """SAFE: subprocess with fixed command and validated args"""
    import shlex
    host = request.args.get("host", "127.0.0.1")
    host = shlex.quote(host)
    subprocess.run(["ping", "-c", "1", host])
    return jsonify({"status": "ok"})
