"""
Test Fixture: Information leak vulnerabilities
"""
import os
import traceback
from flask import Flask, request, jsonify
from django.http import JsonResponse

app = Flask(__name__)


# --- Django Leaks ---

# settings.py equivalent
DEBUG = True  # VULN: Debug mode in production
SECRET_KEY = "django-insecure-abc123def456ghi789jkl"  # VULN: Hardcoded secret
DATABASE_PASSWORD = "myp@ssw0rd"  # VULN: Hardcoded password
STRIPE_SECRET_KEY = "sk_live_abc123..."  # VULN: API key hardcoded


# --- Flask Leaks ---

app.config["DEBUG"] = True  # VULN: Debug mode
app.secret_key = "dev-secret-key-123"  # VULN: Weak secret key


@app.route("/debug")
def debug_info():
    """VULN: Detailed error info exposed"""
    try:
        result = 1 / 0
    except Exception as e:
        return jsonify({
            "error": str(e),
            "traceback": traceback.format_exc(),
            "locals": str(locals()),
        })


@app.route("/login", methods=["POST"])
def login():
    """VULN: User enumeration"""
    email = request.form.get("email")
    password = request.form.get("password")
    user = find_user(email)
    if not user:
        return jsonify({"error": "User not found"})  # 区分了"用户不存在"
    if not check_password(user, password):
        return jsonify({"error": "Invalid password"})  # 和"密码错误"
    return jsonify({"status": "ok"})


@app.route("/safe-login", methods=["POST"])
def safe_login():
    """SAFE: Unified error message"""
    email = request.form.get("email")
    password = request.form.get("password")
    user = find_user(email)
    if not user or not check_password(user, password):
        return jsonify({"error": "Invalid credentials"})  # 统一消息
    return jsonify({"status": "ok"})


# --- Helpers ---
def find_user(email):
    return {"email": "test@example.com", "password": "hashed..."}

def check_password(user, password):
    return user["password"] == password
