"""
Test Fixture: SSRF vulnerabilities
"""
import requests
import urllib.request
from fastapi import FastAPI, Query

app = FastAPI()


@app.get("/fetch")
async def fetch_url(url: str = Query()):
    """VULN: SSRF via requests.get with user-controlled URL"""
    resp = requests.get(url)
    return {"content": resp.text}


@app.get("/proxy")
async def proxy(url: str = Query()):
    """VULN: SSRF via urllib with no validation"""
    resp = urllib.request.urlopen(url)
    return {"content": resp.read().decode()}


@app.get("/webhook")
async def webhook(callback_url: str = Query()):
    """VULN: Blind SSRF via POST to user-controlled URL"""
    requests.post(callback_url, json={"status": "ok"})
    return {"sent": True}


@app.get("/safe-fetch")
async def safe_fetch(url: str = Query()):
    """SAFE: URL whitelist validation"""
    from urllib.parse import urlparse
    ALLOWED_HOSTS = {"api.example.com", "cdn.example.com"}
    parsed = urlparse(url)
    if parsed.hostname not in ALLOWED_HOSTS:
        return {"error": "Host not allowed"}
    resp = requests.get(url)
    return {"content": resp.text}
