"""
Test Fixture: Django SQL Injection vulnerabilities
"""
from django.http import JsonResponse
from django.db import connection


def get_user_by_id(request):
    """VULN: SQL injection via f-string in raw SQL"""
    user_id = request.GET.get("id")
    cursor = connection.cursor()
    cursor.execute(f"SELECT * FROM users WHERE id = {user_id}")
    row = cursor.fetchone()
    return JsonResponse({"user": row})


def search_users(request):
    """VULN: SQL injection via string formatting in raw SQL"""
    name = request.GET.get("name")
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM users WHERE name = '%s'" % name)
    rows = cursor.fetchall()
    return JsonResponse({"users": rows})


def list_users(request):
    """VULN: SQL injection via string concatenation"""
    order = request.GET.get("order_by", "id")
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM users ORDER BY " + order)
    rows = cursor.fetchall()
    return JsonResponse({"users": rows})


def safe_user_query(request):
    """SAFE: Parameterized query"""
    user_id = request.GET.get("id")
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM users WHERE id = %s", [user_id])
    row = cursor.fetchone()
    return JsonResponse({"user": row})
