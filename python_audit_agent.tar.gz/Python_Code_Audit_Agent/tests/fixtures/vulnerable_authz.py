"""
Test Fixture: Authorization bypass vulnerabilities
"""
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required, permission_required
from django.views import View
from flask import Flask, session, redirect, request
from functools import wraps


# --- Django Missing Auth ---

def admin_panel(request):
    """VULN: No authentication required for admin function"""
    all_users = [
        {"id": 1, "email": "admin@example.com"},
        {"id": 2, "email": "user@example.com"},
    ]
    return JsonResponse({"users": all_users})


def delete_user(request, user_id):
    """VULN: No auth or ownership check on destructive action"""
    from django.contrib.auth.models import User
    User.objects.filter(id=user_id).delete()
    return JsonResponse({"deleted": True})


def edit_document(request, doc_id):
    """VULN: No object-level authorization (IDOR)"""
    from .models import Document
    doc = Document.objects.get(id=doc_id)
    doc.title = request.POST.get("title")
    doc.save()
    return JsonResponse({"updated": True})


# --- Safe Django ---

@login_required
def safe_admin_panel(request):
    """SAFE: Protected with login_required"""
    return JsonResponse({"status": "admin panel"})


@permission_required("auth.delete_user")
def safe_delete_user(request, user_id):
    """SAFE: Protected with permission_required"""
    from django.contrib.auth.models import User
    User.objects.filter(id=user_id).delete()
    return JsonResponse({"deleted": True})


def safe_edit_document(request, doc_id):
    """SAFE: Object-level ownership check"""
    from .models import Document
    doc = Document.objects.get(id=doc_id, owner=request.user)
    doc.title = request.POST.get("title")
    doc.save()
    return JsonResponse({"updated": True})
