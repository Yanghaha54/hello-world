"""
Test Fixture: File read/write vulnerabilities (path traversal + upload)
"""
import os
from pathlib import Path
from django.http import FileResponse, HttpResponse
from flask import Flask, send_file, send_from_directory, request

app = Flask(__name__)


# --- File Read / Path Traversal ---

def download_file(request):
    """VULN: Path traversal via open()"""
    filename = request.GET.get("file")
    file_path = f"/app/data/{filename}"
    return FileResponse(open(file_path, "rb"))


@app.route("/download")
def flask_download():
    """VULN: Path traversal via send_file"""
    filename = request.args.get("file")
    return send_file(f"/app/uploads/{filename}")


@app.route("/static/<path:filepath>")
def flask_static(filepath):
    """VULN: send_from_directory without path sanitization"""
    return send_from_directory("/app/static", filepath)


# --- File Upload ---

@app.route("/upload", methods=["POST"])
def upload_file():
    """VULN: File upload without type validation"""
    file = request.files["file"]
    file.save(f"/app/uploads/{file.filename}")
    return {"status": "ok"}


def django_upload(request):
    """VULN: File upload without validation"""
    uploaded = request.FILES["document"]
    with open(f"/app/media/{uploaded.name}", "wb") as f:
        f.write(uploaded.read())
    return HttpResponse("Uploaded")


# --- Safe Versions ---

@app.route("/safe-download")
def safe_flask_download():
    """SAFE: Using safe_join + basename"""
    from werkzeug.utils import safe_join
    import os as _os
    filename = _os.path.basename(request.args.get("file", ""))
    filepath = safe_join("/app/uploads", filename)
    if filepath is None:
        return {"error": "Invalid path"}
    return send_file(filepath)


@app.route("/safe-upload", methods=["POST"])
def safe_upload():
    """SAFE: File upload with extension whitelist"""
    import uuid
    file = request.files["file"]
    ext = os.path.splitext(file.filename)[1].lower()
    ALLOWED = {".jpg", ".png", ".pdf"}
    if ext not in ALLOWED:
        return {"error": "File type not allowed"}, 400
    safe_name = f"{uuid.uuid4()}{ext}"
    file.save(f"/app/uploads/{safe_name}")
    return {"status": "ok", "filename": safe_name}
