# Report Generator Skill

## 功能

将最终漏洞列表转化为结构化、可读的安全审计报告。

## 依赖

- Review Agent 输出的 `final_vulns.json`
- 报告模板: `assets/report-template.md`

## 报告生成逻辑

### 1. 严重程度排序
```
Critical → High → Medium → Low → Info
```

### 2. 章节生成

#### Executive Summary
- 总体风险评级（基于最高 severity + 漏洞数量）
- Top 3 最危险发现
- 统计概要

#### Audit Overview
- 项目信息（框架、文件数、代码量）
- 审计范围和方法论
- 审计时间戳和耗时

#### Vulnerability Details
每个漏洞包含：
- 摘要信息表（Severity, CVSS, CWE, File）
- 描述
- 攻击场景
- 代码对比（Vulnerable vs Fixed）
- 修复建议

#### False Positives
- 被排除的发现列表
- 排除原因

#### Remediation Roadmap
- 短期修复（1周内）
- 中期修复（1月内）
- 长期改进（3月内）

#### Appendix
- Source/Sink 完整清单
- CVE 详细信息
- 审计方法论说明

### 3. 风险评级逻辑

根据 highest_severity + vuln_count 计算总体风险：
- **CRITICAL**: 有 Critical 级别漏洞 或 High 级别 ≥ 5 个
- **HIGH**: 有 High 级别漏洞 或 Medium ≥ 10 个
- **MEDIUM**: 有 Medium 级别漏洞
- **LOW**: 只有 Low/Info 级别
- **INFO**: 无实际漏洞

## 模板变量

| Variable | Source |
|----------|--------|
| `{{timestamp}}` | 审计时间 |
| `{{project_name}}` | 项目名 |
| `{{framework}}` | 检测到的框架 |
| `{{total_files}}` | 扫描文件数 |
| `{{overall_risk}}` | 总体风险评级 |
| `{{vuln_count}}` | 漏洞总数 |
| `{{vuln_summary}}` | 按 severity 分布 |
| `{{critical_findings}}` | Top Critical 漏洞 |
| `{{high_findings}}` | High 漏洞列表 |
| `{{medium_findings}}` | Medium 漏洞列表 |
| `{{low_findings}}` | Low 漏洞列表 |
| `{{false_positives}}` | 误报列表 |
| `{{cve_findings}}` | CVE 结果 |
| `{{remediation_roadmap}}` | 修复路线图 |
| `{{appendix}}` | 附录 |
| `{{endpoint_inventory}}` | 端点审计清单表格 |
| `{{endpoints_audited}}` / `{{total_endpoints}}` | 端点覆盖率分子/分母 |
| `{{endpoint_coverage_percentage}}` | 端点覆盖率 % |
| `{{endpoint_coverage_warning}}` | 端点覆盖率警告 |
| `{{coverage_percentage}}` | 代码覆盖率 % |
| `{{audited_files}}` | LLM 已审计的文件数 |
| `{{files_with_risk_entries}}` | 有风险条目的文件数 |
| `{{files_skipped_with_risk}}` | 有风险但跳过的文件数 |
| `{{audit_gaps}}` | 审计盲区列表 |
| `{{high_complexity_without_risk}}` | 高复杂度但无风险条目的文件 |
| `{{coverage_warnings}}` | 覆盖率警告信息 |
| `{{scanned_files}}` | AST 扫描的文件数 |
