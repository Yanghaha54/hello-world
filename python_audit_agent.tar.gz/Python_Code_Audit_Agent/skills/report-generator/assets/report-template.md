# Python Code Security Audit Report

**Project**: {{project_name}}
**Framework**: {{framework}}
**Generated**: {{timestamp}}
**Auditor**: Claude Code Audit Agent

---

## Executive Summary

- **Overall Risk Level**: 🔴 {{overall_risk}}
- **Total Files Scanned**: {{total_files}}
- **Vulnerabilities Found**: {{vuln_count}} 
  - {{critical_count}} Critical
  - {{high_count}} High
  - {{medium_count}} Medium
  - {{low_count}} Low
- **False Positives Excluded**: {{fp_count}}
- **Dependency CVEs**: {{cve_count}}
- **Code Coverage**: {{coverage_percentage}}% ({{audited_files}}/{{total_files}} files LLM-audited)
- **Endpoint Coverage**: {{endpoint_coverage_percentage}}% ({{endpoints_audited}}/{{total_endpoints}} endpoints audited)

> {{summary_description}}

---

## Audit Overview

| Property | Value |
|----------|-------|
| Project | {{project_name}} |
| Framework | {{framework}} |
| Total Python Files | {{total_files}} |
| Lines of Code | {{total_loc}} |
| Audit Scope | Full codebase review |
| Methodology | AST analysis + Claude LLM deep audit |
| Scan Duration | {{duration}} |

---

## Endpoint Audit Inventory

All external HTTP interfaces discovered and their audit status.

| ID | Method | Path | Handler | Auth | Sources | Sinks | Audit Status | Linked Vulns |
|----|--------|------|---------|------|---------|-------|-------------|--------------|
{{#endpoint_inventory}}
| {{id}} | {{method}} | {{path}} | {{handler}} | {{auth}} | {{source_count}} | {{sink_count}} | {{audit_status}} | {{linked_vulns}} |
{{/endpoint_inventory}}

{{^endpoint_inventory}}
No HTTP endpoints discovered (non-web project or framework not detected).
{{/endpoint_inventory}}

> **Endpoint Coverage**: {{endpoints_audited}}/{{total_endpoints}} endpoints audited ({{endpoint_coverage_percentage}}%)
> 
> ⚠️ {{endpoint_coverage_warning}}

---

## Vulnerability Details

### Critical

{{#critical_findings}}
#### {{id}}: {{title}}

| Field | Value |
|-------|-------|
| **Severity** | 🔴 Critical |
| **CVSS Score** | {{cvss_score}} |
| **CWE** | {{cwe}} |
| **OWASP** | {{owasp}} |
| **Confidence** | {{confidence}} |
| **File** | `{{file}}:{{line}}` |

**Description**: {{description}}

**Attack Scenario**:
```
{{attack_scenario}}
```

**Vulnerable Code** (`{{file}}:{{line_range}}`):
```python
{{vulnerable_code}}
```

**Fixed Code**:
```python
{{fixed_code}}
```

**Remediation**:
1. {{remediation_step_1}}
2. {{remediation_step_2}}
3. {{remediation_step_3}}

**References**:
- CWE-{{cwe_id}}: {{cwe_link}}
- {{additional_ref}}

---
{{/critical_findings}}

### High

{{#high_findings}}
#### {{id}}: {{title}}

| Field | Value |
|-------|-------|
| **Severity** | 🟠 High |
| **CVSS Score** | {{cvss_score}} |
| **CWE** | {{cwe}} |
| **File** | `{{file}}:{{line}}` |
| **Confidence** | {{confidence}} |

**Description**: {{description}}

**Vulnerable Code**:
```python
{{vulnerable_code}}
```

**Fixed Code**:
```python
{{fixed_code}}
```

**Remediation**: {{remediation_summary}}

---
{{/high_findings}}

### Medium

{{#medium_findings}}
#### {{id}}: {{title}}

| Field | Value |
|-------|-------|
| **Severity** | 🟡 Medium |
| **File** | `{{file}}:{{line}}` |

**Description**: {{description}}
**Remediation**: {{remediation_summary}}

---
{{/medium_findings}}

### Low

{{#low_findings}}
#### {{id}}: {{title}}

**File**: `{{file}}:{{line}}`
**Description**: {{description}}

---
{{/low_findings}}

---

## Coverage Analysis

### Code Coverage

| Metric | Value |
|--------|-------|
| Total .py files | {{total_files}} |
| AST scanned | {{scanned_files}} |
| Files with risk entries | {{files_with_risk_entries}} |
| LLM audited | {{audited_files}} |
| Coverage rate | {{coverage_percentage}}% |
| Files skipped (with risk) | {{files_skipped_with_risk}} |

### Audit Gaps

The following files contain risk entries but were **NOT reviewed by the LLM**:

{{#audit_gaps}}
| File | Complexity | Risk Entries | Skip Reason |
|------|-----------|-------------|-------------|
| {{file}} | {{complexity_score}} | {{risk_entries}} | {{reason}} |
{{/audit_gaps}}

{{^audit_gaps}}
No audit gaps — all files with risk entries were LLM-audited.
{{/audit_gaps}}

### High Complexity Files Without Risk Entries

These files have high cyclomatic complexity but no risk entries were found by AST. 
They may contain vulnerabilities that static analysis missed:

{{#high_complexity_without_risk}}
| File | Complexity | Lines | Recommendation |
|------|-----------|-------|----------------|
| {{file}} | {{complexity}} | {{lines}} | Manual review recommended |
{{/high_complexity_without_risk}}

{{^high_complexity_without_risk}}
No high-complexity blind spots.
{{/high_complexity_without_risk}}

{{#coverage_warnings}}
> ⚠️ **Coverage Warning**: {{message}}
{{/coverage_warnings}}

---

## False Positives

The following findings were reviewed and determined to be false positives:

{{#false_positives}}
| ID | Original Finding | Reason | Original Confidence |
|----|-----------------|--------|--------------------|
| {{id}} | {{description}} | {{reason}} | {{confidence}} |
{{/false_positives}}

{{^false_positives}}
No false positives identified.
{{/false_positives}}

---

## Remediation Roadmap

### Immediate (1 Week)

{{#urgent_fixes}}
- [ ] **{{priority}}** {{action}} — `{{file}}`
{{/urgent_fixes}}

### Short-term (1 Month)

{{#short_term_fixes}}
- [ ] {{action}} — `{{file}}`
{{/short_term_fixes}}

### Long-term (3 Months)

{{#long_term_fixes}}
- [ ] {{action}}
{{/long_term_fixes}}

### Security Best Practices

- [ ] Integrate `bandit` SAST into CI/CD pipeline
- [ ] Integrate `safety` dependency scanning
- [ ] Enable Django/Flask security middleware
- [ ] Conduct regular penetration testing
- [ ] Implement security code review process

---

## Appendix A: Dependency CVE Details

{{#cve_findings}}
| Package | Current | Fixed | CVE | CVSS | Description |
|---------|---------|-------|-----|------|-------------|
| {{package}} | {{version}} | {{fixed_version}} | {{cve_id}} | {{cvss}} | {{summary}} |
{{/cve_findings}}

{{^cve_findings}}
No known CVEs found in dependencies.
{{/cve_findings}}

---

## Appendix B: Source/Sink Inventory

### Sources (User Input Entry Points)

| Count | Type | Framework |
|-------|------|-----------|
{{#source_inventory}}
| {{count}} | {{type}} | {{framework}} |
{{/source_inventory}}

### Sinks (Dangerous Function Calls)

| Count | Type | Severity |
|-------|------|----------|
{{#sink_inventory}}
| {{count}} | {{type}} | {{severity}} |
{{/sink_inventory}}

---

## Appendix C: Audit Methodology

This audit was performed using the Python Code Audit Agent, which combines:

1. **AST Static Analysis**: Python AST parsing to identify source/sink patterns
2. **Dataflow Tracking**: Cross-function data path tracing
3. **Claude LLM Deep Audit**: Semantic-level vulnerability analysis
4. **Multi-Agent Review**: Scan → Audit → Review → Report pipeline

The audit methodology follows OWASP guidelines and covers the OWASP Top 10 vulnerability categories.

---

*Report generated by Python Code Audit Agent on {{timestamp}}*
