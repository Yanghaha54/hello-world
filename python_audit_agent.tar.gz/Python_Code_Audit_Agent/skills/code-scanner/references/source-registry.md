# Source Registry — 用户输入入口注册表

定义各 Python Web 框架中用户输入入口的函数和模式。

## Django

| Entry Point | Pattern | Trust Level | Description |
|------------|---------|-------------|-------------|
| `request.GET.get("key")` | `request.GET.get` | 0.0 | URL query parameter |
| `request.GET["key"]` | `request.GET[*]` | 0.0 | URL query parameter (dict access) |
| `request.POST.get("key")` | `request.POST.get` | 0.0 | Form POST data |
| `request.POST["key"]` | `request.POST[*]` | 0.0 | Form POST data (dict access) |
| `request.POST.getlist("key")` | `request.POST.getlist` | 0.0 | Multi-value form data |
| `request.body` | `request.body` | 0.0 | Raw HTTP body |
| `request.FILES.get("key")` | `request.FILES.get` | 0.1 | File upload |
| `request.META.get("key")` | `request.META.get` | 0.1 | HTTP headers |
| `request.COOKIES.get("key")` | `request.COOKIES.get` | 0.1 | Cookie values |
| `request.META["HTTP_*"]` | `request.META[*]` | 0.1 | HTTP header (dict access) |
| `request.resolver_match.kwargs` | `*.resolver_match.kwargs` | 0.0 | URL path parameters |
| URL pattern capture group | `<int:pk>` | 0.0 | URL route parameter |

## Flask

| Entry Point | Pattern | Trust Level | Description |
|------------|---------|-------------|-------------|
| `request.args.get("key")` | `request.args.get` | 0.0 | URL query parameter |
| `request.args["key"]` | `request.args[*]` | 0.0 | URL query parameter (dict access) |
| `request.form.get("key")` | `request.form.get` | 0.0 | Form POST data |
| `request.form["key"]` | `request.form[*]` | 0.0 | Form POST data (dict access) |
| `request.json` / `request.get_json()` | `request.json` / `request.get_json` | 0.0 | JSON request body |
| `request.data` | `request.data` | 0.0 | Raw request data |
| `request.files["key"]` | `request.files[*]` | 0.1 | File upload |
| `request.headers.get("key")` | `request.headers.get` | 0.1 | HTTP headers |
| `request.cookies.get("key")` | `request.cookies.get` | 0.1 | Cookie values |
| `request.view_args["key"]` | `request.view_args[*]` | 0.0 | URL route parameters |
| `request.values.get("key")` | `request.values.get` | 0.0 | Combined args + form |

## FastAPI

| Entry Point | Pattern | Trust Level | Description |
|------------|---------|-------------|-------------|
| `Query()` | `*.Query` | 0.0 | Query parameter dependency |
| `Body()` | `*.Body` | 0.0 | Request body dependency |
| `Path()` | `*.Path` | 0.0 | URL path parameter dependency |
| `Header()` | `*.Header` | 0.1 | Header dependency |
| `Cookie()` | `*.Cookie` | 0.1 | Cookie dependency |
| `File()` | `*.File` | 0.1 | File upload dependency |
| `Form()` | `*.Form` | 0.0 | Form data dependency |
| `request.query_params` | `*.query_params` | 0.0 | Starlette request query params |
| `request.path_params` | `*.path_params` | 0.0 | Starlette request path params |
| `request.headers` | `*.headers` | 0.1 | Starlette request headers |

## Generic Python

| Entry Point | Pattern | Trust Level | Description |
|------------|---------|-------------|-------------|
| `input()` | `input` | 0.0 | Standard input |
| `sys.stdin.read()` | `sys.stdin.read` | 0.0 | Standard input stream |
| `sys.argv` | `sys.argv` | 0.0 | CLI arguments |
| `os.environ.get("key")` | `os.environ.get` | 0.4 | Environment variable |
| `os.environ["key"]` | `os.environ[*]` | 0.4 | Environment variable (dict) |
| `open(user_path)` | `open` | 0.2 | File read (with variable path) |
| `Path(user_path).read_text()` | `Path.read_text` | 0.2 | File read (pathlib) |
| `urllib.request.urlopen(url)` | `*.urlopen` | 0.2 | External HTTP response |
| `requests.get(url).text` | `*.text` | 0.2 | HTTP response body |
| `requests.get(url).json()` | `*.json` | 0.2 | HTTP response JSON |
| `socket.recv()` | `socket.recv` | 0.1 | Network socket data |

## Trust Level 说明

- **0.0**: 完全由外部用户控制，不可信
- **0.1**: 可能被用户控制（header、cookie 伪造）
- **0.2**: 外部数据源（文件、网络），有一定风险
- **0.4**: 环境变量，通常攻击者难以直接控制
- **0.5+**: 部分可信
