# Sink Registry — 危险函数调用注册表

定义各 Python Web 框架和通用 Python 中的危险函数（安全漏洞 Sink 点）。

## Command Execution (命令注入)

| Function | Framework | Severity | Description |
|----------|-----------|----------|-------------|
| `os.system(cmd)` | Generic | **Critical** | Shell 命令执行 |
| `os.popen(cmd)` | Generic | **Critical** | Shell 命令执行，返回管道 |
| `subprocess.call(cmd, shell=True)` | Generic | **Critical** | 子进程调用 |
| `subprocess.Popen(cmd, shell=True)` | Generic | **Critical** | 子进程创建 |
| `subprocess.run(cmd, shell=True)` | Generic | **Critical** | 子进程运行 |
| `subprocess.check_output(cmd, shell=True)` | Generic | **Critical** | 子进程输出捕获 |
| `subprocess.check_call(cmd, shell=True)` | Generic | **Critical** | 子进程调用检查 |
| `os.execve(path, args)` | Generic | **Critical** | 进程替换 |
| `os.execl(path, arg)` | Generic | **Critical** | 进程替换 |
| `pty.spawn(cmd)` | Generic | **Critical** | 伪终端创建 |
| `commands.getoutput(cmd)` | Python 2 | **Critical** | 已废弃但可能存在于旧项目 |

## Code Execution (代码注入)

| Function | Severity | Description |
|----------|----------|-------------|
| `eval(expr)` | **Critical** | Python 表达式求值 |
| `exec(code)` | **Critical** | Python 代码执行 |
| `compile(source, ...)` | **Critical** | 编译代码对象（常配合 exec 使用） |
| `__import__(name)` | **High** | 动态模块导入 |
| `importlib.import_module(name)` | **High** | 动态导入模块 |

## SQL Execution (SQL 注入)

| Function | Framework | Severity | Description |
|----------|-----------|----------|-------------|
| `cursor.execute(query)` | Django DB | **High** | Raw SQL 游标执行 |
| `cursor.executemany(query)` | Django DB | **High** | 批量 SQL 执行 |
| `RawSQL(sql)` | Django ORM | **High** | 原始 SQL 表达式 |
| `Model.objects.raw(sql)` | Django ORM | **High** | 原始 SQL 查询 |
| `Model.objects.extra(where=...)` | Django ORM | **High** | 额外 SQL 条件 |
| `connection.cursor()` | Django DB | **Medium** | 数据库连接游标 |
| `db.session.execute(text(query))` | SQLAlchemy | **Medium** | SQLAlchemy text() 查询 |
| `engine.execute(query)` | SQLAlchemy | **High** | Direct engine execution |
| `sqlite3.execute(query)` | sqlite3 | **High** | SQLite raw 执行 |
| `psycopg2.execute(query)` | psycopg2 | **High** | PostgreSQL raw 执行 |

## Deserialization (反序列化)

| Function | Severity | Description |
|----------|----------|-------------|
| `pickle.load(file)` | **Critical** | Pickle 反序列化 |
| `pickle.loads(data)` | **Critical** | Pickle 字符串反序列化 |
| `yaml.load(data)` | **Critical** | YAML unsafe load（可构造 Python 对象）|
| `yaml.full_load(data)` | **High** | YAML full load |
| `marshal.loads(data)` | **Critical** | Marshal 反序列化 |
| `dill.loads(data)` | **Critical** | Dill 反序列化（比 pickle 更危险）|
| `jsonpickle.decode(data)` | **High** | JSONPickle 反序列化 |
| `shelve.open(file)` | **High** | Shelve（内部使用 pickle）|
| `torch.load(file)` | **High** | PyTorch 模型加载（内部使用 pickle）|

## XSS / HTML Injection

| Function | Framework | Severity | Description |
|----------|-----------|----------|-------------|
| `mark_safe(str)` | Django | **Medium** | 标记字符串为安全（绕过转义）|
| `format_html(str, ...)` | Django | **Medium** | 条件性安全 HTML |
| `render_template_string(str)` | Flask | **Medium** | 字符串模板渲染 |
| `Markup(str)` | Flask/MarkupSafe | **Medium** | 标记为安全 HTML |
| `HTMLResponse(content)` | FastAPI/Starlette | **Medium** | 直接返回 HTML |
| `HttpResponse(content)` | Django | **Low** | HTTP 响应（通常已转义）|

## SSRF

| Function | Framework | Severity | Description |
|----------|-----------|----------|-------------|
| `requests.get(url)` | Generic | **High** | HTTP GET 请求 |
| `requests.post(url)` | Generic | **High** | HTTP POST 请求 |
| `requests.request(method, url)` | Generic | **High** | 通用 HTTP 请求 |
| `urllib.request.urlopen(url)` | Generic | **High** | URL 打开 |
| `httpx.get(url)` | Generic | **High** | HTTPX GET 请求 |
| `httpx.AsyncClient.get(url)` | Generic | **High** | HTTPX 异步 GET |
| `aiohttp.ClientSession().get(url)` | Generic | **High** | aiohttp GET |
| `urllib3.PoolManager().request(url=url)` | Generic | **High** | urllib3 请求 |

## File Operations (路径遍历 / 任意文件读取)

| Function | Framework | Severity | Description |
|----------|-----------|----------|-------------|
| `open(user_path)` | Generic | **Medium** | 文件打开（路径可控）|
| `send_file(user_path)` | Flask | **Medium** | 文件发送 |
| `send_from_directory(dir, user_path)` | Flask | **Medium** | 目录文件发送 |
| `FileResponse(user_path)` | FastAPI/Starlette | **Medium** | 文件响应 |
| `Path(user_path).read_text()` | Generic | **Medium** | Pathlib 文件读取 |
| `Path(user_path).read_bytes()` | Generic | **Medium** | Pathlib 文件读取 |
| `shutil.copy(user_path, dst)` | Generic | **Medium** | 文件复制 |
| `tarfile.extractall(path=user_path)` | Generic | **High** | Tar 提取（路径遍历风险）|

## XXE (XML External Entity)

| Function | Framework | Severity | Description |
|----------|-----------|----------|-------------|
| `etree.parse(xml)` | lxml | **High** | XML 解析 |
| `etree.fromstring(xml)` | lxml | **High** | XML 字符串解析 |
| `ElementTree.parse(xml)` | xml.etree | **High** | XML 解析 |
| `ElementTree.fromstring(xml)` | xml.etree | **High** | XML 字符串解析 |
| `xml.sax.parse(xml)` | xml.sax | **High** | SAX XML 解析 |
| `minidom.parse(xml)` | xml.dom | **High** | DOM XML 解析 |

## Template Injection (模板注入)

| Function | Framework | Severity | Description |
|----------|-----------|----------|-------------|
| `Template(user_input).render()` | Jinja2 | **Critical** | Jinja2 用户可控模板 |
| `Environment().from_string(user_input)` | Jinja2 | **Critical** | 用户可控模板源 |
| `render_template_string(user_input)` | Flask | **Critical** | Flask 模板字符串 |
| `django.template.Template(user_input)` | Django | **High** | Django 模板（较少场景）|

## File Upload

| Pattern | Framework | Severity | Description |
|---------|-----------|----------|-------------|
| `file.save(path)` | Flask/Werkzeug | **High** | 文件保存（无校验）|
| `default_storage.save(name, file)` | Django | **Medium** | 默认存储保存 |
| `UploadFile` without validation | FastAPI | **Medium** | 上传文件未校验 |
| `shutil.copy(fileobj, dst)` | Generic | **Medium** | 文件对象复制 |
