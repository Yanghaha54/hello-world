# Route Patterns Reference — 各框架路由模式注册表

定义 Python Web 框架中所有可检测的 HTTP 路由模式。供 `endpoint_scanner.py` 和 Agent 使用。

## Django

### urlpatterns 中的路由定义
```python
# urls.py
from django.urls import path, re_path, include

urlpatterns = [
    path("users/<int:pk>/", views.user_detail, name="user-detail"),
    path("api/", include("api.urls")),                           # 需要递归解析
    re_path(r"^articles/(?P<slug>[-\w]+)/$", views.article),
    path("admin/", admin.site.urls),
]
```

### 检测项
- **`path()`**: 提取路径和视图处理程序
- **`re_path()`**: 提取正则路径（参数可能无法完整解析）
- **`include()`**: 递归读取引用的 URL 模块，合并 URL 前缀
- **视图引用**: 函数引用 (`views.my_view`)、字符串引用 (`"app.views.my_view"`)、CBV (`.as_view()`)、ViewSet (`.as_view({"get": "list"})`)

### Django REST Framework 额外模式
```python
from rest_framework.decorators import action
from rest_framework.routers import DefaultRouter

router = DefaultRouter()
router.register(r"users", UserViewSet, basename="user")

class UserViewSet(ModelViewSet):
    @action(detail=True, methods=["post"], url_path="activate")
    def activate(self, request, pk=None):
        ...
```

### DRF 检测项
- **`@action`**: 从 `detail`、`methods`、`url_path` 参数提取
- **`@route`**: (旧版 DRF)
- **`DefaultRouter`/`SimpleRouter`**: 自动生成 RESTful 路由（`{prefix}/`, `{prefix}/{lookup}/` 等）

### Django Ninja
```python
from ninja import Router

router = Router()

@router.get("/items/{item_id}")
def get_item(request, item_id: int):
    ...
```
检测 `@router.get/post/put/delete/patch`，类似于 FastAPI。

---

## Flask

### @app.route() 装饰器
```python
from flask import Flask, Blueprint

app = Flask(__name__)
bp = Blueprint("api", __name__)

@app.route("/users/<int:user_id>")
def get_user(user_id):
    ...

@bp.route("/items", methods=["GET", "POST"])
def items():
    ...

app.register_blueprint(bp, url_prefix="/api")
```

### 检测项
- **`@app.route(path, methods=[...])`**: 直接在 `app` 对象上
- **`@bp.route(path, methods=[...])`**: Blueprint 路由；需要匹配 `register_blueprint(bp, url_prefix=...)`
- **Blueprint 注册**: 全局收集 → 在第二个 pass 中解析 url_prefix
- **路径参数**: `<int:id>`、`<string:name>`、`<uuid:id>`、`<path:filepath>`、`<float:value>`
- **`add_url_rule()`**: `app.add_url_rule("/path", view_func=handler)`

---

## FastAPI

### 装饰器路由
```python
from fastapi import FastAPI, APIRouter

app = FastAPI()
router = APIRouter()

@app.get("/items/{item_id}")
async def get_item(item_id: int):
    ...

@router.post("/items", response_model=Item)
async def create_item(item: Item):
    ...

app.include_router(router, prefix="/api/v1")
```

### 检测项
- **`@app.get/post/put/delete/patch/head/options/trace`**: 标准 HTTP 方法装饰器
- **`@app.api_route(path, methods=[...])`**: 多方法路由
- **`@router.*`**: APIRouter 方法；需要匹配 `include_router(router, prefix=...)`
- **路径参数**: `{item_id}` 在路径中，类型通过函数签名中的类型注解推断
- **查询参数**: 函数参数中的 `Query()` 默认值被推断为查询参数
- **请求体**: 函数参数中的 `Body()` 或未注解的复杂类型被推断为请求体参数

### WebSocket 路由
```python
@app.websocket("/ws/{client_id}")
async def websocket_endpoint(websocket: WebSocket, client_id: str):
    ...
```
检测 `@app.websocket(path)` — 带有 `method: "WS"` 的单独端点。

### Starlette (底层)
```python
from starlette.routing import Route, Router, WebSocketRoute

routes = [
    Route("/users", endpoint=list_users, methods=["GET"]),
    Route("/users", endpoint=create_user, methods=["POST"]),
    WebSocketRoute("/ws", endpoint=ws_handler),
]
app = Router(routes=routes)
```
检测 `Route()` 构造 — 更少见，但对于裸 Starlette 应用重要。

---

## Sanic (次要框架)

```python
from sanic import Sanic

app = Sanic("my_app")

@app.route("/users/<user_id:int>", methods=["GET", "POST"])
async def user_handler(request, user_id):
    ...
```

---

## Tornado (次要框架)

```python
import tornado.web

class MainHandler(tornado.web.RequestHandler):
    def get(self):
        ...

app = tornado.web.Application([
    (r"/", MainHandler),
    (r"/users/(\d+)", UserHandler),
])
```

---

## 认证检测

对于每个端点，确定其认证要求：

| 框架 | 装饰器 | Auth Level |
|------|--------|------------|
| Django | `@login_required` | required |
| Django | `@permission_required("perm")` | required |
| Django | `@staff_member_required` | admin |
| Django | `@user_passes_test(fn)` | required |
| Django REST | `permission_classes = [IsAuthenticated]` | required |
| Django REST | `permission_classes = [AllowAny]` | none |
| Flask | `@login_required` (Flask-Login) | required |
| Flask | `@jwt_required` (Flask-JWT) | required |
| FastAPI | `Depends(get_current_user)` | required |
| FastAPI | 无认证依赖 | none |

### 复杂情况
- **Middleware 认证**: 某些应用在 middleware 中处理认证（例如，对某些路径全局应用`@login_required`）。这无法通过装饰器检测，会被标记为 `unknown`。
- **条件认证**: `@user_passes_test(lambda u: ...)` — 无法静态评估，标记为 `required`。
- **视图类级别权限**: Django CBV 可能定义 `permission_classes` 作为类属性。需要检查类体。

---

## 动态路由（静态检测的限制）

这些模式无法可靠地通过静态分析检测：

1. **Django `path()` 中使用 `get_absolute_url()`**: URL 在运行时解析。
2. **Flask 的 `url_for()`**: 不揭示路径。
3. **数据库驱动的 URL**: 从数据库或配置文件加载的路由。
4. **Django CMS / Wagtail 页面路由**: 动态内容路由。
5. **极其动态的 `re_path(r'.*')`**: 如果不存在声明性定义，则无法为覆盖率跟踪/端点清单计数。

### 缓解措施
- 在 `endpoints.json` 中标记带有 `"coverage_status": "dynamic_cannot_track"` 的动态路由。
- 报告“已发现端点数，无法静态发现的端点可能未审计”的警告。
- 鼓励开发者添加 `# @endpoint GET /path` 注释，以便通过注释解析进行静态发现。

---

## 端点 → Source/Sink 映射

确定端点后，source 和 sink 通过以下方式与端点关联：

1. **处理程序文件 + 行**: 将端点处理程序位置与 `source["file"]` 和 `sink["file"]` 中的文件匹配。
2. **处理程序函数名**: 如果 source/sink 在同一文件 + 同一处理程序函数内（基于行号范围），则它属于该端点。
3. **调用链**: 如果 source/sink 在 endpoint handler 调用的被调用函数中，则它被该 endpoint **间接** 使用。

每个端点获得：
```json
{
  "id": "EP-0001",
  "audit_status": "pending",           // pending | audited | skipped | partial
  "linked_risk_entries": ["RISK-001"],  // 关联的 risk_entry IDs
  "linked_vulnerabilities": [],         // 确认的漏洞 IDs
  "coverage": "full"                    // full | partial | none
}
```
