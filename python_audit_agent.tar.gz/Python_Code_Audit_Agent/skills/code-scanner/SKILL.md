# Code Scanner Skill — 代码扫描基础设施

提供 Python 代码的静态分析能力：AST 解析、代码索引、Source/Sink 识别、数据流追踪。

## 适用场景

- Scan Agent 调用此 skill 执行 Phase 1-3 的扫描任务
- 为 Audit Agent 提供结构化的风险点数据

## 模块说明

### scripts/ast_parser.py
Python AST 解析器，负责：
- 解析 Python 源文件为 AST
- 提取函数调用、变量赋值、导入语句
- 识别用户输入入口（Source）和危险函数调用（Sink）
- 框架特定模式匹配
- 将 source/sink 关联到对应的 HTTP 端点

### scripts/indexer.py
代码索引器，负责：
- 遍历项目目录构建文件列表
- 提取函数/类/方法签名
- 构建模块依赖图和调用图
- 文件级圈复杂度评分
- 提取路由装饰器 hints（供 endpoint_scanner 使用）

### scripts/endpoint_scanner.py
**NEW** HTTP 端点枚举器，负责：
- 提取所有 HTTP 路由（Django urlpatterns、Flask route、FastAPI 装饰器）
- 解析 URL 路径、HTTP 方法、认证要求
- 展开 include() 和 Blueprint 前缀链
- 输出完整的外部接口清单 endpoints.json

### scripts/dataflow.py
数据流追踪器，负责：
- 从 Source 点出发的变量传播路径
- 跨函数/跨文件的数据流追踪
- Sanitizer 检测和有效性评估
- **端点关联**：将风险条目分组到 endpoint
- **覆盖率快照**：生成文件和端点的覆盖率基线数据

### references/source-registry.md
Source 函数注册表，列出各框架的用户输入入口。

### references/sink-registry.md
Sink 函数注册表，列出各框架的危险函数。

### references/route-patterns.md
路由模式参考，列出各框架支持的所有路由定义模式，供 endpoint_scanner 使用。

## 使用方式

在 Skill 上下文中，Agent 调用对应脚本：
```
运行 scripts/indexer.py <project_root> → 生成 index.json
运行 scripts/ast_parser.py <file_list> <framework> → 标记 source/sink
运行 scripts/dataflow.py <index.json> <source_sink.json> → 生成 dataflow.json
```
