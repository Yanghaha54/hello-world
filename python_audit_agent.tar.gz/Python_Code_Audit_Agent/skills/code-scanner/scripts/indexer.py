#!/usr/bin/env python3
"""
Python Code Indexer — 项目代码索引

遍历 Python 项目，构建：
1. 文件列表与模块树
2. 函数/类/方法签名
3. 导入关系与模块依赖图
4. 调用图（Call Graph）
5. 圈复杂度评分（文件级）
6. 路由装饰器 hints（供 endpoint_scanner 使用）

输出: index.json
"""

import ast
import os
import sys
import json
from collections import defaultdict
from pathlib import Path
from typing import Any


class ProjectIndexer(ast.NodeVisitor):
    """项目代码索引器"""

    def __init__(self, project_root: str, exclude_dirs: list[str] | None = None):
        self.project_root = Path(project_root).resolve()
        self.exclude_dirs = set(exclude_dirs or DEFAULT_EXCLUDE_DIRS)

        # 索引数据
        self.files: list[dict[str, Any]] = []
        self.modules: dict[str, dict[str, Any]] = {}
        self.functions: dict[str, dict[str, Any]] = {}
        self.classes: dict[str, dict[str, Any]] = {}
        self.imports: dict[str, list[str]] = defaultdict(list)  # file -> [imports]
        self.call_graph: dict[str, list[str]] = defaultdict(list)  # caller -> [callees]

        self._current_file: str = ""
        self._current_class: str | None = None

    def index(self) -> dict[str, Any]:
        """执行全量索引"""
        py_files = list(self._collect_py_files())

        for filepath in py_files:
            self._index_file(filepath)

        return self._build_index_output(py_files)

    def _collect_py_files(self) -> list[Path]:
        """收集所有 .py 文件"""
        py_files: list[Path] = []
        for root, dirs, files in os.walk(self.project_root):
            dirs[:] = [d for d in dirs if d not in self.exclude_dirs and not d.startswith(".")]
            for f in files:
                if f.endswith(".py"):
                    py_files.append(Path(root) / f)
        return sorted(py_files)

    def _index_file(self, filepath: Path) -> None:
        """索引单个文件"""
        self._current_file = str(filepath.relative_to(self.project_root))
        self._current_class = None

        try:
            with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
                source = f.read()
        except Exception:
            return

        try:
            tree = ast.parse(source, filename=str(filepath))
        except SyntaxError:
            return

        file_info = {
            "path": self._current_file,
            "size_bytes": filepath.stat().st_size,
            "lines": len(source.splitlines()),
            "functions": [],
            "classes": [],
            "imports": [],
            "complexity_score": 0,
            "endpoint_hints": [],
        }

        # 提取顶层信息
        for node in ast.iter_child_nodes(tree):
            if isinstance(node, ast.FunctionDef):
                func_info = self._extract_function(node)
                file_info["functions"].append(func_info["name"])
                self.functions[f"{self._current_file}:{func_info['name']}"] = func_info

            elif isinstance(node, ast.ClassDef):
                class_info = self._extract_class(node)
                file_info["classes"].append(class_info["name"])
                self.classes[f"{self._current_file}:{class_info['name']}"] = class_info

            elif isinstance(node, (ast.Import, ast.ImportFrom)):
                imports = self._extract_imports(node)
                file_info["imports"].extend(imports)
                self.imports[self._current_file].extend(imports)

        # 圈复杂度评分
        file_info["complexity_score"] = self._calculate_complexity(tree)

        # 端点 hints (路由装饰器)
        file_info["endpoint_hints"] = self._extract_endpoint_hints(tree)

        self.files.append(file_info)

        # 使用 visitor 提取调用图
        self.visit(tree)

    def _extract_function(self, node: ast.FunctionDef) -> dict[str, Any]:
        """提取函数签名"""
        decorators = []
        for dec in node.decorator_list:
            if isinstance(dec, ast.Name):
                decorators.append(dec.id)
            elif isinstance(dec, ast.Attribute):
                decorators.append(self._get_attr_name(dec))
            elif isinstance(dec, ast.Call):
                if isinstance(dec.func, ast.Name):
                    decorators.append(dec.func.id)

        args = [arg.arg for arg in node.args.args]
        returns = self._get_annotation(node.returns) if node.returns else None

        return {
            "name": node.name,
            "file": self._current_file,
            "line": node.lineno,
            "end_line": node.end_lineno,
            "args": args,
            "returns": returns,
            "decorators": decorators,
            "is_async": isinstance(node, ast.AsyncFunctionDef),
            "docstring": ast.get_docstring(node),
        }

    def _extract_class(self, node: ast.ClassDef) -> dict[str, Any]:
        """提取类签名"""
        bases = []
        for base in node.bases:
            if isinstance(base, ast.Name):
                bases.append(base.id)
            elif isinstance(base, ast.Attribute):
                bases.append(self._get_attr_name(base))

        methods = []
        for child in node.body:
            if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
                method_info = self._extract_function(child)
                method_info["parent_class"] = node.name
                methods.append(method_info)
                self.functions[f"{self._current_file}:{node.name}.{child.name}"] = method_info

        return {
            "name": node.name,
            "file": self._current_file,
            "line": node.lineno,
            "bases": bases,
            "methods": [m["name"] for m in methods],
            "decorators": [],
        }

    def _extract_imports(self, node: ast.Import | ast.ImportFrom) -> list[str]:
        """提取导入信息"""
        imports = []
        if isinstance(node, ast.Import):
            for alias in node.names:
                imports.append(alias.name)
        elif isinstance(node, ast.ImportFrom):
            module = node.module or ""
            for alias in node.names:
                imports.append(f"{module}.{alias.name}" if module else alias.name)
        return imports

    def _get_attr_name(self, node: ast.Attribute) -> str:
        parts = []
        current: Any = node
        while isinstance(current, ast.Attribute):
            parts.insert(0, current.attr)
            current = current.value
        if isinstance(current, ast.Name):
            parts.insert(0, current.id)
        return ".".join(parts)

    def _get_annotation(self, node: ast.AST) -> str | None:
        if isinstance(node, ast.Name):
            return node.id
        if isinstance(node, ast.Attribute):
            return self._get_attr_name(node)
        if isinstance(node, ast.Constant):
            return str(node.value)
        return None

    def visit_Call(self, node: ast.Call) -> None:
        """记录函数调用用于构建 Call Graph"""
        func_name = None
        if isinstance(node.func, ast.Name):
            func_name = node.func.id
        elif isinstance(node.func, ast.Attribute):
            func_name = self._get_attr_name(node.func)

        if func_name:
            caller = f"{self._current_file}"
            self.call_graph[caller].append(func_name)

        self.generic_visit(node)

    def _calculate_complexity(self, tree: ast.AST) -> int:
        """文件级圈复杂度评分"""
        score = 1  # base
        for node in ast.walk(tree):
            if isinstance(node, (ast.If, ast.While, ast.For, ast.AsyncFor,
                                 ast.ExceptHandler, ast.With, ast.AsyncWith,
                                 ast.And, ast.Or, ast.Try)):
                score += 1
            elif isinstance(node, ast.Match):  # Python 3.10+
                score += len(node.cases)
            elif isinstance(node, ast.FunctionDef):
                score += 1  # each function adds complexity
        return score

    def _extract_endpoint_hints(self, tree: ast.AST) -> list[dict[str, Any]]:
        """提取路由装饰器 hints"""
        hints = []
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                for decorator in node.decorator_list:
                    dname = None
                    if isinstance(decorator, ast.Name):
                        dname = decorator.id
                    elif isinstance(decorator, ast.Attribute):
                        dname = self._get_attr_name(decorator)
                    elif isinstance(decorator, ast.Call):
                        if isinstance(decorator.func, ast.Name):
                            dname = decorator.func.id
                        elif isinstance(decorator.func, ast.Attribute):
                            dname = self._get_attr_name(decorator.func)

                    if not dname:
                        continue

                    # Flask: .route(), FastAPI: .get/.post/etc
                    ROUTE_PATTERNS = {"route", "get", "post", "put", "delete", "patch",
                                      "head", "options", "api_route", "websocket"}
                    for pattern in ROUTE_PATTERNS:
                        if dname == pattern or dname.endswith(f".{pattern}"):
                            hints.append({
                                "handler": node.name,
                                "line": node.lineno,
                                "decorator": dname,
                            })
                            break
        return hints

    def _build_index_output(self, py_files: list[Path]) -> dict[str, Any]:
        """构建输出"""
        return {
            "project_root": str(self.project_root),
            "total_files": len(py_files),
            "total_py_files": len(self.files),
            "files": self.files,
            "functions": {k: v for k, v in list(self.functions.items())[:2000]},
            "classes": {k: v for k, v in list(self.classes.items())[:500]},
            "imports_graph": dict(self.imports),
            "call_graph": dict(self.call_graph),
            "stats": {
                "total_functions": len(self.functions),
                "total_classes": len(self.classes),
                "files_with_imports": len(self.imports),
                "avg_complexity": round(
                    sum(f.get("complexity_score", 0) for f in self.files) / max(len(self.files), 1), 1
                ),
                "high_complexity_files": len(
                    [f for f in self.files if f.get("complexity_score", 0) > 20]
                ),
                "files_with_endpoint_hints": len(
                    [f for f in self.files if f.get("endpoint_hints", [])]
                ),
            },
        }


DEFAULT_EXCLUDE_DIRS = [
    "venv", ".venv", "env", ".env", "__pycache__", ".git",
    ".idea", ".vscode", "node_modules", "migrations", "tests",
    "test", "docs", "static", "media", "dist", "build", ".tox",
    ".mypy_cache", ".pytest_cache", ".eggs", "*.egg-info",
]


def index_project(project_root: str, exclude_dirs: list[str] | None = None) -> dict[str, Any]:
    """便捷函数：索引整个项目"""
    indexer = ProjectIndexer(project_root, exclude_dirs)
    return indexer.index()


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python indexer.py <project_root> [output.json]")
        sys.exit(1)

    root = sys.argv[1]
    output_file = sys.argv[2] if len(sys.argv) > 2 else "index.json"

    result = index_project(root)
    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, ensure_ascii=False, default=str)

    print(f"Indexed {result['total_py_files']} files -> {output_file}")
    print(f"  Functions: {result['stats']['total_functions']}")
    print(f"  Classes: {result['stats']['total_classes']}")
