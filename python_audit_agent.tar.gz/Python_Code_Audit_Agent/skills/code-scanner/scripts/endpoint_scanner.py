#!/usr/bin/env python3
"""
Endpoint Scanner — HTTP 路由枚举与外部接口发现

从 Python Web 项目中提取所有 HTTP 端点（路由），输出结构化 JSON。

支持：
- Django: urlpatterns 中的 path()/re_path()/include() + DRF @action/@route
- Flask: @app.route() + @blueprint.route() 装饰器
- FastAPI: @app.get/post/put/delete/patch + @router.* 装饰器

输出: endpoints.json — 每个端点的完整元数据 + 关联的 source/sink
"""

import ast
import os
import sys
import json
import re
from pathlib import Path
from collections import defaultdict
from typing import Any


class EndpointScanner:
    """HTTP 端点提取器"""

    def __init__(self, project_root: str, framework: str = "auto",
                 exclude_dirs: list[str] | None = None):
        self.project_root = Path(project_root).resolve()
        self.framework = framework
        self.exclude_dirs = set(exclude_dirs or DEFAULT_EXCLUDE_DIRS)

        self.endpoints: list[dict[str, Any]] = []
        self._url_prefix_stack: list[str] = []  # Django include() 嵌套
        self._blueprint_registry: dict[str, str] = {}  # Flask Blueprint -> prefix映射
        self._router_registry: dict[str, str] = {}  # FastAPI APIRouter -> prefix映射
        self._current_file: str = ""

    def scan(self) -> dict[str, Any]:
        """扫描项目，提取所有端点"""
        py_files = self._collect_py_files()

        # Pass 1: 收集路由定义
        for filepath in py_files:
            self._scan_file(filepath)

        # Pass 2: 解析 Django urlpatterns (需要全局视图)
        self._resolve_django_urls(py_files)

        # Pass 3: 去重 + 排序 + 分配 ID
        self._deduplicate_and_assign_ids()

        return self._build_output()

    # ---- Pass 1: 逐文件扫描 ----

    def _scan_file(self, filepath: Path) -> None:
        """扫描单个文件，提取路由信息"""
        self._current_file = str(filepath.relative_to(self.project_root))

        try:
            with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
                source = f.read()
        except Exception:
            return

        try:
            tree = ast.parse(source, filename=str(filepath))
        except SyntaxError:
            return

        # 检测文件是否包含路由定义
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                self._check_route_decorators(node)

            elif isinstance(node, ast.Assign):
                self._check_django_urlpatterns(node)

            elif isinstance(node, ast.Call):
                self._check_blueprint_registration(node)
                self._check_router_registration(node)

    def _check_route_decorators(self, node: ast.FunctionDef) -> None:
        """检测函数装饰器中的路由定义 (Flask + FastAPI)"""
        handler_func = node.name
        handler_line = node.lineno
        auth_required = self._has_auth_decorator(node)

        for decorator in node.decorator_list:
            route_info = self._parse_route_decorator(decorator)
            if not route_info:
                continue

            methods = route_info["methods"]
            path = route_info["path"]
            framework = route_info["framework"]

            # 解析路径参数
            params = self._extract_path_params(path, framework)

            endpoint = {
                "file": self._current_file,
                "handler": handler_func,
                "line": handler_line,
                "methods": methods,
                "path": path,
                "framework": framework,
                "auth_required": auth_required,
                "parameters": params,
                "source": "decorator",
            }
            self.endpoints.append(endpoint)

    def _parse_route_decorator(self, decorator: ast.expr) -> dict[str, Any] | None:
        """解析路由装饰器，提取 methods + path + framework"""
        call = None
        func_name = None

        if isinstance(decorator, ast.Call):
            call = decorator
            if isinstance(decorator.func, ast.Attribute):
                func_name = self._get_attr_name(decorator.func)
            elif isinstance(decorator.func, ast.Name):
                func_name = decorator.func.id
        elif isinstance(decorator, ast.Attribute):
            func_name = self._get_attr_name(decorator)
            call = None

        if not func_name:
            return None

        # Flask: @app.route("/path", methods=["GET", "POST"])
        # Flask: @bp.route("/path")
        if func_name.endswith(".route") or func_name == "route":
            if call and call.args:
                path = self._eval_string(call.args[0])
                methods = self._extract_methods_from_call(call)
                return {"path": path, "methods": methods, "framework": "flask"}

        # FastAPI: @app.get("/path"), @app.post("/path"), etc.
        HTTP_METHODS = {"get", "post", "put", "delete", "patch", "head", "options", "trace"}
        for method in HTTP_METHODS:
            if func_name.endswith(f".{method}") or func_name == method:
                if call and call.args:
                    path = self._eval_string(call.args[0])
                    return {"path": path, "methods": [method.upper()], "framework": "fastapi"}

        # FastAPI: @app.api_route("/path", methods=["GET", "POST"])
        if func_name.endswith(".api_route") or func_name == "api_route":
            if call and call.args:
                path = self._eval_string(call.args[0])
                methods = self._extract_methods_from_call(call)
                return {"path": path, "methods": methods, "framework": "fastapi"}

        # Django REST Framework: @action(detail=True, methods=["post"])
        if func_name == "action" or func_name.endswith(".action"):
            if call:
                methods = self._extract_methods_from_call(call)
                path = self._extract_kwarg(call, "url_path") or handler_func.replace("_", "-")
                return {"path": f"/{path}", "methods": methods, "framework": "django"}

        return None

    def _check_django_urlpatterns(self, node: ast.Assign) -> None:
        """检测 Django urlpatterns 赋值"""
        for target in node.targets:
            if isinstance(target, ast.Name) and target.id == "urlpatterns":
                if isinstance(node.value, ast.List):
                    for elt in node.value.elts:
                        self._parse_urlpattern_element(elt)

    def _parse_urlpattern_element(self, node: ast.expr, prefix: str = "") -> None:
        """递归解析 urlpatterns 中的元素"""
        if isinstance(node, ast.Call):
            func_name = None
            if isinstance(node.func, ast.Name):
                func_name = node.func.id
            elif isinstance(node.func, ast.Attribute):
                func_name = self._get_attr_name(node.func)

            if not func_name:
                return

            # path("users/<int:id>", views.user_detail, name="user-detail")
            if func_name in ("path", "re_path"):
                if node.args:
                    url_pattern = self._eval_string(node.args[0])
                    full_path = prefix + url_pattern
                    handler_info = self._parse_django_handler(node.args[1]) if len(node.args) > 1 else None
                    if handler_info:
                        params = self._extract_path_params(url_pattern, "django")
                        endpoint = {
                            "file": handler_info.get("file", self._current_file),
                            "handler": handler_info.get("handler", "unknown"),
                            "line": handler_info.get("line", 0),
                            "methods": ["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"],
                            "path": full_path,
                            "framework": "django",
                            "auth_required": "unknown",  # 在 Pass 2 中解析
                            "parameters": params,
                            "source": f"urlpatterns {func_name}()",
                        }
                        self.endpoints.append(endpoint)

            # include("app.urls") or include(("app.urls", "app"), namespace="app")
            elif func_name == "include":
                if node.args:
                    included = self._eval_string(node.args[0]) if isinstance(node.args[0], ast.Constant) else None
                    if included and included.endswith(".urls"):
                        # 延迟 — 将在 _resolve_django_urls 中处理
                        pass

    def _parse_django_handler(self, node: ast.expr) -> dict[str, Any] | None:
        """解析 Django 视图处理程序引用"""
        if isinstance(node, ast.Attribute):
            return {
                "handler": node.attr,
                "file": self._current_file,
                "line": node.lineno if hasattr(node, 'lineno') else 0,
            }
        elif isinstance(node, ast.Call) and hasattr(node.func, 'value'):
            # views.MyViewSet.as_view({"get": "list"})
            if isinstance(node.func.value, ast.Attribute):
                return None  # CBV — 太复杂，后续处理
        return None

    def _check_blueprint_registration(self, node: ast.Call) -> None:
        """检测 Flask Blueprint 注册"""
        if isinstance(node.func, ast.Attribute) and node.func.attr == "register_blueprint":
            if node.args:
                bp_name = self._get_name(node.args[0])
                url_prefix = self._extract_kwarg(node, "url_prefix") or ""
                if bp_name:
                    self._blueprint_registry[bp_name] = url_prefix

    def _check_router_registration(self, node: ast.Call) -> None:
        """检测 FastAPI APIRouter include"""
        if isinstance(node.func, ast.Attribute) and node.func.attr == "include_router":
            if node.args:
                router_name = self._get_name(node.args[0])
                prefix = self._extract_kwarg(node, "prefix") or ""
                if router_name:
                    self._router_registry[router_name] = prefix

    # ---- Pass 2: 解析 Django URL 包含 ----

    def _resolve_django_urls(self, py_files: list[Path]) -> None:
        """解析 Django include()，展开 URL 前缀链"""
        # 这是静态分析的简化版本
        # 完整解析需要处理: path('api/', include('app.urls'))
        # → 读取 app/urls.py → 提取 urlpatterns → 添加 /api/ 前缀

        # 遍历 url.py 文件，寻找 include() 调用
        for filepath in py_files:
            if not filepath.name.endswith(".py"):
                continue
            try:
                with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
                    source = f.read()
            except Exception:
                continue
            try:
                tree = ast.parse(source, filename=str(filepath))
            except SyntaxError:
                continue

            self._current_file = str(filepath.relative_to(self.project_root))
            for node in ast.walk(tree):
                if isinstance(node, ast.Assign):
                    for target in node.targets:
                        if isinstance(target, ast.Name) and target.id == "urlpatterns":
                            if isinstance(node.value, ast.List):
                                self._resolve_includes(node.value.elts, "")

    def _resolve_includes(self, elements: list[ast.expr], prefix: str) -> None:
        """递归解析 urlpatterns 中的 include() """
        for elt in elements:
            if isinstance(elt, ast.Call):
                func_name = None
                if isinstance(elt.func, ast.Name):
                    func_name = elt.func.id
                elif isinstance(elt.func, ast.Attribute):
                    func_name = self._get_attr_name(elt.func)

                if func_name in ("path", "re_path"):
                    if len(elt.args) >= 2:
                        url_part = self._eval_string(elt.args[0]) if elt.args else ""
                        if isinstance(elt.args[1], ast.Call):
                            inner_call = elt.args[1]
                            inner_func = None
                            if isinstance(inner_call.func, ast.Name):
                                inner_func = inner_call.func.id
                            elif isinstance(inner_call.func, ast.Attribute):
                                inner_func = self._get_attr_name(inner_call.func)

                            if inner_func == "include":
                                module_ref = self._eval_string(inner_call.args[0]) if inner_call.args else None
                                if module_ref:
                                    self._resolve_module_urlpatterns(module_ref, prefix + url_part)

    def _resolve_module_urlpatterns(self, module_ref: str, prefix: str) -> None:
        """解析引用的模块中的 urlpatterns"""
        # 将 "app.urls" 转为 "app/urls.py"
        module_path = module_ref.replace(".", "/")
        if not module_path.endswith(".py"):
            module_path += ".py"

        resolved_path = self.project_root / module_path
        if not resolved_path.exists():
            return

        try:
            with open(resolved_path, "r", encoding="utf-8", errors="ignore") as f:
                source = f.read()
        except Exception:
            return

        try:
            tree = ast.parse(source, filename=str(resolved_path))
        except SyntaxError:
            return

        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name) and target.id == "urlpatterns":
                        if isinstance(node.value, ast.List):
                            for elt in node.value.elts:
                                self._parse_urlpattern_element(elt, prefix)

    # ---- Pass 3: 去重 + 排序 + ID 分配 ----

    def _deduplicate_and_assign_ids(self) -> None:
        """去重、排序、分配唯一 ID"""
        seen: set[str] = set()
        unique: list[dict[str, Any]] = []

        for ep in self.endpoints:
            # 规范化路径
            ep["path"] = self._normalize_path(ep.get("path", ""))
            for method in ep.get("methods", ["GET"]):
                key = f"{method}:{ep['path']}:{ep.get('handler', '')}:{ep.get('file', '')}"
                if key not in seen:
                    seen.add(key)
                    unique.append(ep)
                else:
                    break  # 已经覆盖了这个端点

        # 按路径排序
        unique.sort(key=lambda x: (x.get("path", ""), x.get("methods", [""])[0]))

        # 分配 ID
        for i, ep in enumerate(unique, 1):
            ep["id"] = f"EP-{i:04d}"

        # 按认证要求分类
        public = [ep for ep in unique if ep.get("auth_required") == "none"]
        authenticated = [ep for ep in unique if ep.get("auth_required") == "required"]
        admin = [ep for ep in unique if ep.get("auth_required") == "admin"]
        unknown_auth = [ep for ep in unique if ep.get("auth_required") == "unknown"]

        self.endpoints = unique
        self._auth_stats = {
            "public": len(public),
            "authenticated": len(authenticated),
            "admin": len(admin),
            "unknown": len(unknown_auth),
        }

    # ---- Helpers ----

    def _collect_py_files(self) -> list[Path]:
        py_files: list[Path] = []
        for root, dirs, files in os.walk(self.project_root):
            dirs[:] = [d for d in dirs if d not in self.exclude_dirs and not d.startswith(".")]
            for f in files:
                if f.endswith(".py"):
                    py_files.append(Path(root) / f)
        return sorted(py_files)

    def _get_attr_name(self, node: ast.Attribute) -> str:
        parts = []
        current: Any = node
        while isinstance(current, ast.Attribute):
            parts.insert(0, current.attr)
            current = current.value
        if isinstance(current, ast.Name):
            parts.insert(0, current.id)
        return ".".join(parts)

    def _get_name(self, node: ast.expr) -> str | None:
        if isinstance(node, ast.Name):
            return node.id
        if isinstance(node, ast.Attribute):
            return self._get_attr_name(node)
        return None

    def _eval_string(self, node: ast.expr) -> str:
        """安全地求值字符串常量"""
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            return node.value
        if isinstance(node, ast.Str):  # Python 3.7 compatibility
            return node.s
        # f-string / 连接: 尽力而为
        if isinstance(node, ast.JoinedStr):
            parts = []
            for v in node.values:
                if isinstance(v, ast.Constant):
                    parts.append(str(v.value))
            return "".join(parts)
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
            left = self._eval_string(node.left)
            right = self._eval_string(node.right)
            return left + right
        return "<dynamic>"

    def _extract_methods_from_call(self, call: ast.Call) -> list[str]:
        """从函数调用中提取 methods 参数"""
        for kw in call.keywords:
            if kw.arg == "methods":
                if isinstance(kw.value, ast.List):
                    methods = []
                    for elt in kw.value.elts:
                        if isinstance(elt, ast.Constant):
                            methods.append(str(elt.value).upper())
                    return methods if methods else ["GET"]
        return ["GET"]  # 默认

    def _extract_kwarg(self, call: ast.Call, key: str) -> str | None:
        """从函数调用中提取关键字参数"""
        for kw in call.keywords:
            if kw.arg == key:
                return self._eval_string(kw.value)
        return None

    def _has_auth_decorator(self, func_node: ast.FunctionDef) -> str:
        """检测认证装饰器"""
        for decorator in func_node.decorator_list:
            dname = None
            if isinstance(decorator, ast.Name):
                dname = decorator.id
            elif isinstance(decorator, ast.Attribute):
                dname = self._get_attr_name(decorator)
            elif isinstance(decorator, ast.Call):
                if isinstance(decorator.func, ast.Name):
                    dname = decorator.func.id
                elif isinstance(decorator.func, ast.Attribute):
                    dname = self._get_attr_name(decorator.func)

            if dname:
                AUTH_DECORATORS = {
                    "login_required": "required",
                    "permission_required": "required",
                    "staff_member_required": "admin",
                    "user_passes_test": "required",
                    "LoginRequired": "required",
                    "jwt_required": "required",
                    "requires_auth": "required",
                }
                for pattern, level in AUTH_DECORATORS.items():
                    if dname == pattern or dname.endswith(f".{pattern}"):
                        return level
        return "none"

    def _extract_path_params(self, path: str, framework: str) -> list[dict[str, str]]:
        """从路径字符串中提取参数"""
        params: list[dict[str, str]] = []

        if framework == "django":
            # /api/users/<int:pk>/posts/<slug:slug>/
            django_pattern = re.compile(r"<(\w+):(\w+)>")
            for m in django_pattern.finditer(path):
                params.append({"name": m.group(2), "type": m.group(1), "source": "url_path"})
        elif framework == "flask":
            # /api/users/<int:pk>/posts/<slug>
            flask_pattern = re.compile(r"<(\w+:)?(\w+)>")
            for m in flask_pattern.finditer(path):
                type_str = m.group(1).rstrip(":") if m.group(1) else "string"
                params.append({"name": m.group(2), "type": type_str, "source": "url_path"})
        elif framework == "fastapi":
            # /api/users/{user_id}/posts/{post_id}
            fastapi_pattern = re.compile(r"\{(\w+)\}")
            for m in fastapi_pattern.finditer(path):
                params.append({"name": m.group(1), "source": "url_path", "type": "any"})

        return params

    def _normalize_path(self, path: str) -> str:
        """规范化路径"""
        if not path:
            return "/"
        if not path.startswith("/"):
            path = "/" + path
        # 去除尾部斜杠
        while len(path) > 1 and path.endswith("/"):
            path = path[:-1]
        return path

    def _build_output(self) -> dict[str, Any]:
        """构建最终输出"""
        framework_counts: dict[str, int] = defaultdict(int)
        for ep in self.endpoints:
            framework_counts[ep.get("framework", "unknown")] += 1

        return {
            "total_endpoints": len(self.endpoints),
            "by_framework": dict(framework_counts),
            "by_auth": self._auth_stats,
            "endpoints": self.endpoints,
        }


DEFAULT_EXCLUDE_DIRS = [
    "venv", ".venv", "env", ".env", "__pycache__", ".git",
    ".idea", ".vscode", "node_modules", "migrations", "tests",
    "test", "docs", "static", "media", "dist", "build", ".tox",
    ".mypy_cache", ".pytest_cache",
]


def scan_endpoints(project_root: str, framework: str = "auto",
                   exclude_dirs: list[str] | None = None) -> dict[str, Any]:
    """便捷函数：扫描项目端点"""
    scanner = EndpointScanner(project_root, framework, exclude_dirs)
    return scanner.scan()


def link_to_sources_sinks(endpoints_data: dict[str, Any],
                          source_sink_data: list[dict[str, Any]]) -> dict[str, Any]:
    """将端点与 source/sink 关联"""
    # 构建 handler -> source/sink 映射
    handler_sources: dict[str, list] = defaultdict(list)
    handler_sinks: dict[str, list] = defaultdict(list)

    for file_data in source_sink_data:
        fpath = file_data.get("file", "")
        for src in file_data.get("sources", []):
            handler_sources[f"{fpath}:{src.get('line', 0)}"].append(src)
        for snk in file_data.get("sinks", []):
            handler_sinks[f"{fpath}:{snk.get('line', 0)}"].append(snk)

    # 为每个端点关联 source/sink
    for ep in endpoints_data.get("endpoints", []):
        file = ep.get("file", "")
        # 端点的 handler 行附近的 source/sink
        ep["linked_sources"] = []
        ep["linked_sinks"] = []
        # 简化关联：基于文件的匹配
        for src in handler_sources.get(file, []):
            ep["linked_sources"].append(src.get("type"))
        for snk in handler_sinks.get(file, []):
            ep["linked_sinks"].append(snk.get("type"))

    return endpoints_data


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python endpoint_scanner.py <project_root> [framework] [output.json]")
        sys.exit(1)

    root = sys.argv[1]
    framework = sys.argv[2] if len(sys.argv) > 2 else "auto"
    output_file = sys.argv[3] if len(sys.argv) > 3 else "endpoints.json"

    result = scan_endpoints(root, framework)
    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, ensure_ascii=False)

    print(f"Endpoint scanning complete: {result['total_endpoints']} endpoints -> {output_file}")
    for fw, count in result.get("by_framework", {}).items():
        print(f"  {fw}: {count}")
    for auth_level, count in result.get("by_auth", {}).items():
        print(f"  auth={auth_level}: {count}")
