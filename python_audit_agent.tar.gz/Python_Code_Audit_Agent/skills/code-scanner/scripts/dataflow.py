#!/usr/bin/env python3
"""
Dataflow Tracker — Source → Sink 数据流追踪

基于代码索引和 Source/Sink 标记，追踪用户输入从 Source 到 Sink 的传播路径。

策略：
1. 从 Source 点出发，追踪变量赋值和传递
2. 在调用链中追踪跨函数的数据流
3. 检查传播路径上是否存在 Sanitizer
4. 控制追踪深度（call_depth）和范围
"""

import json
import sys
import os
import re
from collections import defaultdict
from typing import Any


class DataflowTracker:
    """数据流追踪器"""

    def __init__(self, index_data: dict[str, Any], source_sink_data: list[dict[str, Any]],
                 endpoints_data: dict = None, max_depth: int = 3):
        self.index = index_data
        self.source_sink_data = source_sink_data
        self.endpoints_data = endpoints_data or {}
        self.max_depth = max_depth

        # 快速查找结构
        self._file_sources: dict[str, list[dict]] = defaultdict(list)
        self._file_sinks: dict[str, list[dict]] = defaultdict(list)
        self._file_sanitizers: dict[str, list[dict]] = defaultdict(list)
        self._variable_defs: dict[str, dict] = {}  # file:var -> def info

        # endpoint 关联追踪
        self._endpoint_risk_map: dict[str, list[str]] = defaultdict(list)  # ep_id -> [risk_ids]
        self._all_scanned_files: set[str] = set()

        self._build_lookup_tables()

    def _build_lookup_tables(self) -> None:
        """构建快速查找表"""
        for file_data in self.source_sink_data:
            fpath = file_data.get("file", "")
            for src in file_data.get("sources", []):
                self._file_sources[fpath].append(src)
            for snk in file_data.get("sinks", []):
                self._file_sinks[fpath].append(snk)
            for san in file_data.get("sanitizers", []):
                self._file_sanitizers[fpath].append(san)

    def track(self) -> list[dict[str, Any]]:
        """追踪所有 Source → Sink 路径"""
        risk_entries: list[dict[str, Any]] = []

        # 记录所有扫描过的文件
        for fpath in self._file_sources:
            self._all_scanned_files.add(fpath)
        for fpath in self._file_sinks:
            self._all_scanned_files.add(fpath)

        for fpath, sources in self._file_sources.items():
            sinks = self._file_sinks.get(fpath, [])
            sanitizers = self._file_sanitizers.get(fpath, [])

            if not sinks:
                continue

            for source in sources:
                for sink in sinks:
                    entry = self._track_single(source, sink, sanitizers, fpath)
                    if entry:
                        risk_entries.append(entry)
                        # 关联 endpoint
                        ep_id = source.get("endpoint_id") or sink.get("endpoint_id")
                        if ep_id:
                            self._endpoint_risk_map[ep_id].append(entry.get("vuln_type", "unknown"))

        # 按风险分数排序
        risk_entries.sort(key=lambda x: x.get("risk_score", 0), reverse=True)
        return risk_entries

    def build_coverage_snapshot(self, risk_entries: list[dict[str, Any]]) -> dict[str, Any]:
        """构建覆盖率快照"""
        files_with_risk: set[str] = set()
        for entry in risk_entries:
            files_with_risk.add(entry.get("source", {}).get("file", ""))

        # 端点覆盖率
        total_eps = len(self.endpoints_data.get("endpoints", []))
        eps_with_risks: set[str] = set()
        for ep_id, risks in self._endpoint_risk_map.items():
            if risks:
                eps_with_risks.add(ep_id)

        # 高复杂度文件列表
        high_complexity_files = []
        for f in self.index.get("files", []):
            if f.get("complexity_score", 0) > 20:
                fpath = f.get("path", "")
                high_complexity_files.append({
                    "file": fpath,
                    "complexity": f.get("complexity_score", 0),
                    "has_risk_entries": fpath in files_with_risk,
                })

        return {
            "scanned_files": len(self._all_scanned_files),
            "total_files": self.index.get("total_py_files", 0),
            "files_with_risk_entries": len(files_with_risk),
            "files_never_scanned": self.index.get("total_py_files", 0) - len(self._all_scanned_files),
            "total_risk_entries": len(risk_entries),
            "endpoints_with_risk": len(eps_with_risks),
            "total_endpoints": total_eps,
            "high_complexity_files": high_complexity_files,
            "high_complexity_without_risk": [
                hf for hf in high_complexity_files if not hf["has_risk_entries"]
            ],
        }

    def build_endpoint_summary(self) -> list[dict[str, Any]]:
        """构建每个端点的风险摘要"""
        summary = []
        for ep in self.endpoints_data.get("endpoints", []):
            ep_id = ep.get("id", "unknown")
            risks = self._endpoint_risk_map.get(ep_id, [])
            summary.append({
                "id": ep_id,
                "method": ep.get("methods", ["?"])[0],
                "path": ep.get("path", "?"),
                "handler": f"{ep.get('file', '')}:{ep.get('handler', '')}",
                "risk_count": len(risks),
                "risk_types": list(set(risks)),
                "framework": ep.get("framework", "unknown"),
                "auth_required": ep.get("auth_required", "unknown"),
                "audit_status": "pending",
            })
        return summary

    def _track_single(self, source: dict, sink: dict, sanitizers: list[dict],
                      fpath: str) -> dict[str, Any] | None:
        """追踪单个 Source-Sink 对"""

        # 计算距离（同一文件内的行号距离）
        src_line = source.get("line", 0)
        sink_line = sink.get("line", 0)
        distance = abs(sink_line - src_line) if src_line and sink_line else float("inf")

        # 检查中间是否有 Sanitizer
        intervening_sanitizers: list[dict] = []
        for san in sanitizers:
            san_line = san.get("line", 0)
            if src_line <= san_line <= sink_line or sink_line <= san_line <= src_line:
                intervening_sanitizers.append(san)

        # 计算有效性
        sanitizer_effectiveness = 0.0
        for san in intervening_sanitizers:
            sanitizer_effectiveness = max(sanitizer_effectiveness,
                                          san.get("effectiveness", 0.5))

        # 风险评分
        base_risk = self._get_base_risk(sink.get("type", ""))
        source_trust = source.get("trust_level", 0.0)
        sanitizer_factor = 1.0 - sanitizer_effectiveness
        distance_factor = max(0.2, 1.0 - (distance / 500))

        risk_score = base_risk * (1.0 - source_trust) * sanitizer_factor * distance_factor
        risk_score = min(10.0, max(0.0, round(risk_score, 1)))

        # 置信度
        confidence = 0.5 + (sanitizer_effectiveness * 0.3) - (source_trust * 0.2)
        if intervening_sanitizers:
            confidence += 0.1
        if distance < 20:
            confidence += 0.15  # 同一小段代码内，关联度更高
        confidence = min(1.0, max(0.0, round(confidence, 2)))

        return {
            "source": {
                "file": fpath,
                "line": src_line,
                "type": source.get("type", "unknown"),
                "code_ref": source.get("func", ""),
            },
            "sink": {
                "file": fpath,
                "line": sink_line,
                "type": sink.get("type", "unknown"),
                "code_ref": sink.get("func", ""),
            },
            "dataflow_distance": distance,
            "sanitizers": [s.get("type") for s in intervening_sanitizers],
            "sanitizer_effectiveness": sanitizer_effectiveness,
            "risk_score": risk_score,
            "confidence": confidence,
            "vuln_type": self._infer_vuln_type(sink.get("type", "")),
        }

    def _get_base_risk(self, sink_type: str) -> float:
        """获取 Sink 类型的基础风险值"""
        risk_map: dict[str, float] = {
            "shell_exec": 9.5, "subprocess_exec": 9.5, "process_replace": 9.5,
            "eval": 9.5, "exec": 9.5, "compile": 9.0,
            "pickle_load": 9.0, "pickle_loads": 9.0, "yaml_unsafe_load": 9.0,
            "yaml_full_load": 8.5, "marshal_loads": 9.0, "dill_loads": 9.0,
            "cursor_execute": 8.5, "cursor_executemany": 8.5, "raw_sql": 8.0,
            "lxml_parse": 8.0, "lxml_fromstring": 8.0, "xml_parse": 7.5,
            "requests_get": 7.0, "urllib_urlopen": 7.0, "httpx_get": 7.0,
            "django_mark_safe": 5.0, "flask_render_string": 5.0,
            "file_open": 5.5, "flask_send_file": 5.5,
            "django_http_response": 3.0,
        }
        return risk_map.get(sink_type, 5.0)

    def _infer_vuln_type(self, sink_type: str) -> str:
        """从 Sink 类型推断漏洞分类"""
        vuln_map: dict[str, str] = {
            "shell_exec": "cmdi", "subprocess_exec": "cmdi", "process_replace": "cmdi",
            "eval": "cmdi", "exec": "cmdi", "compile": "cmdi",
            "pickle_load": "deserialize", "pickle_loads": "deserialize",
            "yaml_unsafe_load": "deserialize", "yaml_full_load": "deserialize",
            "marshal_loads": "deserialize", "dill_loads": "deserialize",
            "cursor_execute": "sqli", "cursor_executemany": "sqli",
            "raw_sql": "sqli", "django_rawsql": "sqli",
            "lxml_parse": "xxe", "xml_parse": "xxe",
            "requests_get": "ssrf", "urllib_urlopen": "ssrf", "httpx_get": "ssrf",
            "django_mark_safe": "xss", "flask_render_string": "xss",
            "markup": "xss", "html_response": "xss",
            "file_open": "file_read", "send_file": "file_read",
            "flask_send_file": "file_read", "file_response": "file_read",
        }
        return vuln_map.get(sink_type, "unknown")


# =============================================================================
# Main
# =============================================================================

def track_dataflow(index_file: str, source_sink_file: str,
                   endpoints_file: str = None, max_depth: int = 3) -> dict[str, Any]:
    """便捷函数：从文件加载数据并追踪，返回完整结果（含覆盖率）"""
    with open(index_file, "r", encoding="utf-8") as f:
        index_data = json.load(f)

    with open(source_sink_file, "r", encoding="utf-8") as f:
        source_sink_data = json.load(f)

    if isinstance(source_sink_data, dict):
        source_sink_data = source_sink_data.get("files", [source_sink_data])

    endpoints_data = {}
    if endpoints_file:
        try:
            with open(endpoints_file, "r", encoding="utf-8") as f:
                endpoints_data = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            pass

    tracker = DataflowTracker(index_data, source_sink_data, endpoints_data, max_depth)
    entries = tracker.track()
    coverage = tracker.build_coverage_snapshot(entries)
    endpoint_summary = tracker.build_endpoint_summary()

    return {
        "total_risk_entries": len(entries),
        "by_severity": {
            "critical": len([r for r in entries if r["risk_score"] >= 9.0]),
            "high": len([r for r in entries if 7.0 <= r["risk_score"] < 9.0]),
            "medium": len([r for r in entries if 4.0 <= r["risk_score"] < 7.0]),
            "low": len([r for r in entries if r["risk_score"] < 4.0]),
        },
        "entries": entries,
        "coverage_snapshot": coverage,
        "endpoint_summary": endpoint_summary,
    }


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python dataflow.py <index.json> <source_sink.json> [endpoints.json] [output.json]")
        sys.exit(1)

    index_file = sys.argv[1]
    source_sink_file = sys.argv[2]
    endpoints_file = sys.argv[3] if len(sys.argv) > 3 else None
    output_file = sys.argv[4] if len(sys.argv) > 4 else "risk_entries.json"

    result = track_dataflow(index_file, source_sink_file, endpoints_file)

    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, ensure_ascii=False)

    print(f"Dataflow tracking complete: {result['total_risk_entries']} risk entries -> {output_file}")
    cov = result.get("coverage_snapshot", {})
    print(f"  Coverage: {cov.get('files_with_risk_entries', 0)}/{cov.get('scanned_files', 0)} files with risks")
    print(f"  Endpoints with risk: {cov.get('endpoints_with_risk', 0)}/{cov.get('total_endpoints', 0)}")
