#!/usr/bin/env python3
"""
Python AST Parser — Source/Sink 识别 & 框架模式匹配

解析 Python 源文件，提取：
1. 用户输入入口（Source points）
2. 危险函数调用（Sink points）
3. 过滤/校验函数（Sanitizers）
4. 框架特定模式
"""

import ast
import os
import sys
import json
import re
from pathlib import Path
from typing import Any


class SourceSinkParser(ast.NodeVisitor):
    """AST 遍历器，识别 Source、Sink 和 Sanitizer"""

    def __init__(self, framework: str = "auto", source_registry: dict = None,
                 sink_registry: dict = None, endpoints_data: dict = None):
        self.framework = framework
        self.source_registry = source_registry or DEFAULT_SOURCE_REGISTRY
        self.sink_registry = sink_registry or DEFAULT_SINK_REGISTRY
        self.endpoints_data = endpoints_data or {}

        self.sources: list[dict[str, Any]] = []
        self.sinks: list[dict[str, Any]] = []
        self.sanitizers: list[dict[str, Any]] = []
        self.imports: dict[str, str] = {}  # alias -> full module
        self.variables: dict[str, dict[str, Any]] = {}  # var name -> def info
        self.current_file: str = ""
        self._current_handler: str | None = None  # 当前所在的路由处理函数
        self._handler_endpoint_map: dict[str, str] = {}  # handler -> endpoint_id

    def parse_file(self, filepath: str) -> dict[str, Any]:
        """解析单个文件"""
        self.current_file = filepath
        self.sources = []
        self.sinks = []
        self.sanitizers = []
        self.imports = {}
        self.variables = {}
        self._current_handler = None
        self._handler_endpoint_map = {}

        # 构建 handler -> endpoint_id 映射
        self._build_handler_endpoint_map(filepath)

        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            source = f.read()
        try:
            tree = ast.parse(source, filename=filepath)
        except SyntaxError as e:
            return {"file": filepath, "error": f"SyntaxError: {e}", "sources": [], "sinks": [], "sanitizers": []}

        self.visit(tree)

        return {
            "file": filepath,
            "sources": self.sources,
            "sinks": self.sinks,
            "sanitizers": self.sanitizers,
            "imports": self.imports,
            "framework_hints": self._detect_framework(),
        }

    def _build_handler_endpoint_map(self, filepath: str) -> None:
        """构建 handler 函数名 -> endpoint_id 的映射（基于文件名匹配）"""
        if not self.endpoints_data:
            return
        # 将文件路径标准化为相对路径
        for ep in self.endpoints_data.get("endpoints", []):
            ep_file = ep.get("file", "")
            # 尝试多种路径格式匹配
            if filepath.endswith(ep_file) or ep_file.endswith(filepath) or filepath == ep_file:
                handler = ep.get("handler", "")
                if handler:
                    self._handler_endpoint_map[handler] = ep.get("id", "unknown")

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        """跟踪当前所在的 handler 函数"""
        prev_handler = self._current_handler
        self._current_handler = node.name
        self.generic_visit(node)
        self._current_handler = prev_handler

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        """跟踪当前所在的 async handler 函数"""
        prev_handler = self._current_handler
        self._current_handler = node.name
        self.generic_visit(node)
        self._current_handler = prev_handler

    def visit_Import(self, node: ast.Import) -> None:
        for alias in node.names:
            name = alias.asname or alias.name
            self.imports[name] = alias.name
        self.generic_visit(node)

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        module = node.module or ""
        for alias in node.names:
            name = alias.asname or alias.name
            self.imports[name] = f"{module}.{alias.name}"
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call) -> None:
        """检查函数调用是否为 Sink 或包含 Source"""
        func_name = self._get_func_name(node.func)
        if not func_name:
            self.generic_visit(node)
            return

        # 检查是否为 Sink
        sink_info = self._match_sink(func_name, node)
        if sink_info:
            self.sinks.append(sink_info)

        # 检查特定模式中的 Source
        source_info = self._match_source(func_name, node)
        if source_info:
            self.sources.append(source_info)

        # 检查是否为 Sanitizer
        sanitizer_info = self._match_sanitizer(func_name, node)
        if sanitizer_info:
            self.sanitizers.append(sanitizer_info)

        self.generic_visit(node)

    def visit_Assign(self, node: ast.Assign) -> None:
        """记录变量赋值"""
        for target in node.targets:
            if isinstance(target, ast.Name):
                self.variables[target.id] = {
                    "line": node.lineno,
                    "col": node.col_offset,
                    "source_line": self._get_source_snippet(node),
                }
        self.generic_visit(node)

    # --- Private helpers ---

    def _get_func_name(self, func_node: ast.AST) -> str | None:
        """从函数调用 node 提取完整函数名"""
        if isinstance(func_node, ast.Name):
            return func_node.id
        if isinstance(func_node, ast.Attribute):
            obj = self._get_attribute_chain(func_node)
            return ".".join(obj)
        if isinstance(func_node, ast.Call):
            return self._get_func_name(func_node.func)
        return None

    def _get_attribute_chain(self, node: ast.Attribute) -> list[str]:
        parts = []
        current: ast.AST = node
        while isinstance(current, ast.Attribute):
            parts.insert(0, current.attr)
            current = current.value
        if isinstance(current, ast.Name):
            parts.insert(0, current.id)
        return parts

    def _get_source_snippet(self, node: ast.AST) -> str:
        """获取节点的源代码片段（简化版）"""
        if hasattr(node, "lineno"):
            return f"line {node.lineno}"
        return "unknown"

    def _get_endpoint_id(self) -> str | None:
        """获取当前所在的 endpoint_id"""
        if self._current_handler and self._current_handler in self._handler_endpoint_map:
            return self._handler_endpoint_map[self._current_handler]
        return None

    def _match_sink(self, func_name: str, node: ast.Call) -> dict[str, Any] | None:
        """匹配合并 Sink 注册表"""
        for category, patterns in self.sink_registry.items():
            for pattern in patterns:
                if self._match_pattern(func_name, pattern["func"]):
                    result = {
                        "type": pattern["type"],
                        "category": category,
                        "func": func_name,
                        "line": node.lineno,
                        "col": node.col_offset,
                        "severity": pattern.get("severity", "medium"),
                        "args_count": len(node.args),
                        "has_keywords": bool(node.keywords),
                    }
                    ep_id = self._get_endpoint_id()
                    if ep_id:
                        result["endpoint_id"] = ep_id
                    return result
        return None

    def _match_source(self, func_name: str, node: ast.Call) -> dict[str, Any] | None:
        """匹配合并 Source 注册表"""
        for category, patterns in self.source_registry.items():
            for pattern in patterns:
                if self._match_pattern(func_name, pattern["func"]):
                    result = {
                        "type": pattern["type"],
                        "category": category,
                        "func": func_name,
                        "line": node.lineno,
                        "col": node.col_offset,
                        "trust_level": pattern.get("trust_level", 0.0),
                    }
                    ep_id = self._get_endpoint_id()
                    if ep_id:
                        result["endpoint_id"] = ep_id
                    return result
        return None

    def _match_sanitizer(self, func_name: str, node: ast.Call) -> dict[str, Any] | None:
        """匹配 Sanitizer 模式"""
        for pattern in SANITIZER_PATTERNS:
            if self._match_pattern(func_name, pattern["func"]):
                return {
                    "type": pattern["type"],
                    "func": func_name,
                    "line": node.lineno,
                    "effectiveness": pattern.get("effectiveness", 0.5),
                }
        return None

    def _match_pattern(self, func_name: str, pattern: str) -> bool:
        """匹配函数名模式，支持通配符 *"""
        # 精确匹配
        if func_name == pattern:
            return True
        # 后缀匹配 (e.g. "*.execute" matches "cursor.execute")
        if pattern.startswith("*."):
            return func_name.endswith(pattern[1:])
        # 包含匹配 (e.g. "*execute*")
        if "*" in pattern:
            regex = re.escape(pattern).replace(r"\*", ".*")
            return bool(re.match(f"^{regex}$", func_name))
        return False

    def _detect_framework(self) -> list[str]:
        """检测使用的框架"""
        hints = []
        imported_modules = set()
        for alias, full in self.imports.items():
            imported_modules.add(full.split(".")[0])
            imported_modules.add(alias)

        if any("django" in m for m in imported_modules):
            hints.append("django")
        if any("flask" in m for m in imported_modules):
            hints.append("flask")
        if any("fastapi" in m for m in imported_modules):
            hints.append("fastapi")
        if any(m in imported_modules for m in ("sqlalchemy", "sqlite3", "psycopg2", "pymysql")):
            hints.append("database")
        if any(m in imported_modules for m in ("celery", "rq", "dramatiq")):
            hints.append("task_queue")
        return hints


# =============================================================================
# Default Registries
# =============================================================================

DEFAULT_SOURCE_REGISTRY: dict[str, list[dict[str, Any]]] = {
    "django_request": [
        {"func": "request.GET.get", "type": "http_get_param", "trust_level": 0.0},
        {"func": "request.POST.get", "type": "http_post_param", "trust_level": 0.0},
        {"func": "request.POST.getlist", "type": "http_post_list", "trust_level": 0.0},
        {"func": "request.body", "type": "http_body", "trust_level": 0.0},
        {"func": "request.FILES.get", "type": "file_upload", "trust_level": 0.1},
        {"func": "request.META.get", "type": "http_header", "trust_level": 0.1},
        {"func": "request.COOKIES.get", "type": "http_cookie", "trust_level": 0.1},
        {"func": "request.META", "type": "http_meta", "trust_level": 0.1},
    ],
    "flask_request": [
        {"func": "request.args.get", "type": "http_get_param", "trust_level": 0.0},
        {"func": "request.form.get", "type": "http_post_param", "trust_level": 0.0},
        {"func": "request.json.get", "type": "http_json_body", "trust_level": 0.0},
        {"func": "request.get_json", "type": "http_json_body", "trust_level": 0.0},
        {"func": "request.files", "type": "file_upload", "trust_level": 0.1},
        {"func": "request.headers.get", "type": "http_header", "trust_level": 0.1},
        {"func": "request.cookies.get", "type": "http_cookie", "trust_level": 0.1},
        {"func": "request.data", "type": "http_body", "trust_level": 0.0},
        {"func": "request.values.get", "type": "http_param", "trust_level": 0.0},
        {"func": "request.view_args", "type": "url_param", "trust_level": 0.0},
    ],
    "fastapi_request": [
        {"func": "*.Query", "type": "query_param", "trust_level": 0.0},
        {"func": "*.Body", "type": "http_body", "trust_level": 0.0},
        {"func": "*.Path", "type": "url_path", "trust_level": 0.0},
        {"func": "*.Header", "type": "http_header", "trust_level": 0.1},
        {"func": "*.Cookie", "type": "http_cookie", "trust_level": 0.1},
        {"func": "*.File", "type": "file_upload", "trust_level": 0.1},
        {"func": "*.Form", "type": "form_param", "trust_level": 0.0},
    ],
    "generic_input": [
        {"func": "input", "type": "stdin_input", "trust_level": 0.0},
        {"func": "sys.stdin.read", "type": "stdin_input", "trust_level": 0.0},
        {"func": "sys.argv", "type": "cli_arg", "trust_level": 0.0},
        {"func": "os.environ.get", "type": "env_var", "trust_level": 0.4},
        {"func": "*.read", "type": "file_read", "trust_level": 0.2},
        {"func": "open", "type": "file_read", "trust_level": 0.2},
        {"func": "*.urlopen", "type": "external_data", "trust_level": 0.2},
        {"func": "*.text", "type": "http_response", "trust_level": 0.2},
        {"func": "*.json", "type": "json_response", "trust_level": 0.2},
    ],
}

DEFAULT_SINK_REGISTRY: dict[str, list[dict[str, Any]]] = {
    "command_execution": [
        {"func": "os.system", "type": "shell_exec", "severity": "critical"},
        {"func": "os.popen", "type": "shell_exec", "severity": "critical"},
        {"func": "subprocess.call", "type": "subprocess_exec", "severity": "critical"},
        {"func": "subprocess.Popen", "type": "subprocess_exec", "severity": "critical"},
        {"func": "subprocess.run", "type": "subprocess_exec", "severity": "critical"},
        {"func": "subprocess.check_output", "type": "subprocess_exec", "severity": "critical"},
        {"func": "os.exec*", "type": "process_replace", "severity": "critical"},
    ],
    "code_execution": [
        {"func": "eval", "type": "eval", "severity": "critical"},
        {"func": "exec", "type": "exec", "severity": "critical"},
        {"func": "compile", "type": "compile", "severity": "critical"},
        {"func": "__import__", "type": "dynamic_import", "severity": "high"},
    ],
    "sql_execution": [
        {"func": "*.execute", "type": "cursor_execute", "severity": "high"},
        {"func": "*.executemany", "type": "cursor_executemany", "severity": "high"},
        {"func": "*.raw", "type": "raw_sql", "severity": "high"},
        {"func": "RawSQL", "type": "django_rawsql", "severity": "high"},
        {"func": "*.extra", "type": "django_extra", "severity": "high"},
        {"func": "*.raw", "type": "orm_raw", "severity": "high"},
        {"func": "text", "type": "sqlalchemy_text", "severity": "medium"},
    ],
    "deserialization": [
        {"func": "pickle.load", "type": "pickle_load", "severity": "critical"},
        {"func": "pickle.loads", "type": "pickle_loads", "severity": "critical"},
        {"func": "yaml.load", "type": "yaml_unsafe_load", "severity": "critical"},
        {"func": "yaml.full_load", "type": "yaml_full_load", "severity": "high"},
        {"func": "marshal.loads", "type": "marshal_loads", "severity": "critical"},
        {"func": "dill.loads", "type": "dill_loads", "severity": "critical"},
        {"func": "jsonpickle.decode", "type": "jsonpickle_decode", "severity": "high"},
    ],
    "xss_output": [
        {"func": "mark_safe", "type": "django_mark_safe", "severity": "medium"},
        {"func": "format_html", "type": "django_format_html", "severity": "medium"},
        {"func": "render_template_string", "type": "flask_render_string", "severity": "medium"},
        {"func": "Markup", "type": "flask_markup", "severity": "medium"},
        {"func": "HTMLResponse", "type": "fastapi_html_response", "severity": "medium"},
        {"func": "HttpResponse", "type": "django_http_response", "severity": "low"},
        {"func": "JsonResponse", "type": "django_json_response", "severity": "low"},
    ],
    "ssrf": [
        {"func": "requests.get", "type": "requests_get", "severity": "high"},
        {"func": "requests.post", "type": "requests_post", "severity": "high"},
        {"func": "requests.request", "type": "requests_request", "severity": "high"},
        {"func": "urllib.request.urlopen", "type": "urllib_urlopen", "severity": "high"},
        {"func": "httpx.get", "type": "httpx_get", "severity": "high"},
        {"func": "httpx.AsyncClient.get", "type": "httpx_async_get", "severity": "high"},
        {"func": "aiohttp.ClientSession.get", "type": "aiohttp_get", "severity": "high"},
    ],
    "file_operations": [
        {"func": "open", "type": "file_open", "severity": "medium"},
        {"func": "send_file", "type": "flask_send_file", "severity": "medium"},
        {"func": "send_from_directory", "type": "flask_send_dir", "severity": "medium"},
        {"func": "FileResponse", "type": "file_response", "severity": "medium"},
        {"func": "Path.read_text", "type": "path_read", "severity": "medium"},
        {"func": "Path.read_bytes", "type": "path_read", "severity": "medium"},
    ],
    "xxe": [
        {"func": "etree.parse", "type": "lxml_parse", "severity": "high"},
        {"func": "etree.fromstring", "type": "lxml_fromstring", "severity": "high"},
        {"func": "ElementTree.parse", "type": "xml_parse", "severity": "high"},
        {"func": "ElementTree.fromstring", "type": "xml_fromstring", "severity": "high"},
        {"func": "xml.sax.parse", "type": "sax_parse", "severity": "high"},
    ],
}

SANITIZER_PATTERNS: list[dict[str, Any]] = [
    {"func": "*.escape", "type": "html_escape", "effectiveness": 0.75},
    {"func": "bleach.clean", "type": "html_clean", "effectiveness": 0.80},
    {"func": "bleach.linkify", "type": "html_linkify", "effectiveness": 0.70},
    {"func": "django.utils.html.escape", "type": "django_escape", "effectiveness": 0.80},
    {"func": "markupsafe.escape", "type": "markupsafe_escape", "effectiveness": 0.75},
    {"func": "html.escape", "type": "html_escape", "effectiveness": 0.75},
    {"func": "urllib.parse.quote", "type": "url_encode", "effectiveness": 0.60},
    {"func": "*.strip", "type": "strip", "effectiveness": 0.10},
    {"func": "int", "type": "type_cast_int", "effectiveness": 0.50},
    {"func": "float", "type": "type_cast_float", "effectiveness": 0.30},
    {"func": "re.match", "type": "regex_match", "effectiveness": 0.40},
    {"func": "re.fullmatch", "type": "regex_fullmatch", "effectiveness": 0.60},
    {"func": "validators.url", "type": "url_validator", "effectiveness": 0.70},
    {"func": "shlex.quote", "type": "shell_escape", "effectiveness": 0.85},
]


# =============================================================================
# Main
# =============================================================================

def parse_file(filepath: str, framework: str = "auto",
               endpoints_data: dict = None) -> dict[str, Any]:
    """便捷函数：解析单个文件"""
    parser = SourceSinkParser(framework=framework, endpoints_data=endpoints_data)
    return parser.parse_file(filepath)


def parse_directory(dirpath: str, framework: str = "auto",
                    exclude_dirs: list[str] | None = None,
                    endpoints_data: dict = None) -> list[dict[str, Any]]:
    """便捷函数：解析整个目录"""
    if exclude_dirs is None:
        exclude_dirs = ["venv", ".venv", "env", "__pycache__", ".git", "node_modules",
                        "migrations", "tests", "test", "docs", ".idea", ".vscode"]

    results = []
    for root, dirs, files in os.walk(dirpath):
        dirs[:] = [d for d in dirs if d not in exclude_dirs]
        for f in files:
            if f.endswith(".py"):
                filepath = os.path.join(root, f)
                result = parse_file(filepath, framework, endpoints_data)
                results.append(result)
    return results


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python ast_parser.py <file_or_dir> [framework]")
        sys.exit(1)

    target = sys.argv[1]
    framework = sys.argv[2] if len(sys.argv) > 2 else "auto"

    if os.path.isfile(target):
        result = parse_file(target, framework)
    else:
        result = parse_directory(target, framework)

    print(json.dumps(result, indent=2, ensure_ascii=False))
