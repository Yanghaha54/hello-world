# XXE Detection Skill

## 检测能力

针对 Python Web 项目检测 XML 外部实体注入 (XXE) 漏洞。

## 危险函数清单

```python
# ❌ HIGH — lxml
from lxml import etree
tree = etree.parse(user_xml)         # 默认解析外部实体
root = etree.fromstring(user_xml)    # 默认解析外部实体

# ❌ HIGH — xml.etree.ElementTree
import xml.etree.ElementTree as ET
tree = ET.parse(user_xml)
root = ET.fromstring(user_xml)

# ❌ HIGH — xml.sax
import xml.sax
xml.sax.parse(user_xml, handler)

# ❌ HIGH — xml.dom
from xml.dom import minidom, pulldom
dom = minidom.parse(user_xml)
# pulldom.parse(user_xml)

# ❌ HIGH — xml.parsers.expat
import xml.parsers.expat
parser = xml.parsers.expat.ParserCreate()
parser.Parse(user_xml)
```

## 安全 vs 不安全

### lxml
```python
# ❌ 危险 — 默认配置
etree.parse(user_xml)
etree.fromstring(user_xml)
etree.XMLParser()  # 默认 resolve_entities=True

# ✅ 安全
parser = etree.XMLParser(resolve_entities=False)
etree.fromstring(user_xml, parser=parser)
etree.parse(user_xml, parser=parser)
```

### ElementTree
```python
# ❌ 危险 — Python < 3.9 默认不防护
ET.fromstring(user_xml)

# ✅ 安全 — Python 3.9+ 默认禁用外部实体
# 但最好显式指定
parser = ET.XMLParser(target=ET.TreeBuilder())
# 或使用 defusedxml
```

### defusedxml (推荐)
```python
# ✅ 安全 — 使用 defusedxml
import defusedxml.ElementTree as ET
tree = ET.parse(user_xml)

import defusedxml.lxml
tree = defusedxml.lxml.parse(user_xml)
```

## 框架特定检测

### 所有框架通用
```python
# ❌ SOAP/XML API 端点
@app.route("/api/xml", methods=["POST"])
def xml_api():
    xml_data = request.data  # 或 request.get_data()
    root = etree.fromstring(xml_data)  # XXE

# ❌ XML 上传
def parse_uploaded_xml(file):
    tree = ET.parse(file)

# ❌ SAML 认证
# python3-saml 或 pysaml2
# 配置不当可能导致 XXE
```

### Django XML 处理
```python
# ❌ 使用 lxml 解析 XML 请求体
def xml_view(request):
    xml_data = request.body
    root = etree.fromstring(xml_data)
```

### 文件格式解析（暗藏 XXE）
```python
# ⚠️ 需检查 — Office 文档解析
# python-docx, openpyxl 等底层可能使用 lxml
# 如果解析用户上传的 .docx → 潜在 XXE

# ⚠️ 需检查 — SVG 解析
# SVG 是 XML 格式，解析可能触发 XXE

# ⚠️ 需检查 — RSS/Atom Feed
# Feedparser 通常安全，但其他解析器可能不安全
```

## 审计判断规则

1. **确认漏洞**: 
   - 使用 lxml 默认解析用户 XML，未设置 resolve_entities=False
   - 使用标准库 xml 模块（Python < 3.9）且未使用 defusedxml
2. **可能误报**: 已使用 defusedxml 替换标准库
3. **需要复核**: 间接使用 XML 解析（如 Office 文档、SAML）
4. **安全**: 
   - `resolve_entities=False`
   - 使用 `defusedxml`
   - Python 3.9+ 的 ET（但最好不依赖默认行为）

## 风险评分

- **High (7-8)**: 解析用户 XML，外部实体未禁用
- **Medium (4-6)**: 使用 Python 3.9+ ET（默认安全但无显式防护）
- **Low (1-3)**: XML 源部分可控

## XXE 攻击影响

成功的 XXE 攻击可导致：
- **文件读取**: 读取服务器文件（/etc/passwd, .env 等）
- **SSRF**: 扫描内网服务
- **DoS**: 实体爆炸 (Billion Laughs Attack)
- **信息泄露**: 外带数据到攻击者服务器
