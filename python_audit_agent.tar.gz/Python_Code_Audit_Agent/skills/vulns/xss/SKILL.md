# XSS Detection Skill

## 检测能力

针对 Python Web 项目检测跨站脚本 (XSS) 漏洞。

## Django XSS 检测

### 危险模式
```python
# ❌ 危险 — mark_safe + 用户输入
from django.utils.safestring import mark_safe
html = mark_safe(user_input)
return HttpResponse(html)

# ❌ 危险 — format_html 拼接用户输入
from django.utils.html import format_html
html = format_html("<div>{}</div>", mark_safe(user_input))

# ❌ 危险 — |safe 过滤
# Template: {{ user_input|safe }}

# ❌ 危险 — @html_safe 装饰器
@html_safe
def get_user_bio(self):
    return self.bio  # 如果 bio 包含用户输入

# ⚠️ 需检查 — json_script
# {{ value|json_script:"hello" }}  — 可能 XSS

# ✅ 安全 — 默认 autoescape
# Django 模板默认转义：{{ user_input }}
```

### 检查点
1. `mark_safe()` 的参数是否来自用户输入
2. 模板中使用 `|safe` 过滤器的地方
3. `format_html()` 的参数是否包含 mark_safe 包装的用户输入
4. `json_script` 过滤的使用

## Flask / Jinja2 XSS 检测

### 危险模式
```python
# ❌ 危险 — render_template_string + 用户输入
return render_template_string("<h1>Hello {{ name }}</h1>", name=user_input)
# (如果 user_input 包含模板语法，可能导致 SSTI)

# ❌ 危险 — Markup + 用户输入
from markupsafe import Markup
return Markup("<div>%s</div>" % user_input)

# ❌ 危险 — |safe 过滤
# Template: {{ user_input|safe }}

# ⚠️ 需检查 — render_template
# 默认转义，但 autoescape=False 时危险
return render_template("page.html", content=user_input)
```

### 检查点
1. 是否使用了 `render_template_string()` 处理用户输入
2. `Markup()` 是否包装了用户数据
3. 模板中 `|safe` 过滤器的使用
4. `autoescape` 是否被关闭

## FastAPI XSS 检测

```python
# ❌ 危险 — HTMLResponse + 用户输入
from fastapi.responses import HTMLResponse
return HTMLResponse(content=f"<div>{user_input}</div>")

# ✅ 安全 — JSONResponse（默认）
return {"data": user_input}
```

## 通用 Python Web XSS

```python
# ❌ 危险 — 直接拼接 HTML
response = f"<html><body>{user_input}</body></html>"
return HttpResponse(response)

# ❌ 危险 — 拼接 JavaScript
script = f"var name = '{user_input}';"  # 反射型 XSS
return HttpResponse(f"<script>{script}</script>")
```

## 审计判断规则

1. **确认漏洞**: 用户输入未转义直接进入 HTML/JavaScript 上下文
2. **存储型 XSS**: 用户输入存入数据库后未转义输出（检查数据库读取 → HTML 输出路径）
3. **反射型 XSS**: URL 参数直接反射到页面
4. **DOM XSS**: 安全的服务器端响应但危险的前端 JavaScript 处理
5. **误报**: 使用 bleach 清洗、Django 默认 autoescape、Jinja2 自动转义

## 风险评分

- **High (7-8)**: 存储型 XSS，影响所有用户
- **Medium (5-6)**: 反射型 XSS，需要用户点击链接
- **Low (3-4)**: DOM XSS 或有限的注入上下文
- **组合风险**: XSS + 敏感 cookie (HttpOnly 缺失) → 升级为 High
