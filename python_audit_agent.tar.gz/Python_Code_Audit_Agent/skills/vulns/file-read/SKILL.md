# Arbitrary File Read Detection Skill

## 检测能力

针对 Python Web 项目检测任意文件读取（路径遍历）漏洞。

## 危险函数清单

```python
# ❌ HIGH — 通用文件操作
open(user_path)
open(user_path, "rb")
Path(user_path).read_text()
Path(user_path).read_bytes()

# ❌ HIGH — 框架文件响应
# Django
from django.http import FileResponse
FileResponse(open(user_path, "rb"))

# Flask
from flask import send_file, send_from_directory
send_file(user_path)
send_from_directory("/app/uploads", user_filename)

# FastAPI
from starlette.responses import FileResponse
FileResponse(user_path)
```

## Django 特定检测

```python
# ❌ 危险 — FileSystemStorage
from django.core.files.storage import FileSystemStorage
fs = FileSystemStorage(location="/app/media")
fs.open(user_path)  # 可能路径遍历

# ❌ 危险 — default_storage
from django.core.files.storage import default_storage
file = default_storage.open(user_path)

# ❌ 危险 — 读取配置文件/源码
config = open(f"/app/configs/{user_config_name}")
source = open(f"/app/views/{user_module}")
```

## Flask 特定检测

```python
# ❌ 危险 — send_file
@app.route("/download")
def download():
    filename = request.args.get("file")
    return send_file(f"/app/files/{filename}")  # ../../../etc/passwd

# ❌ 危险 — send_from_directory（认为安全但可能不够）
@app.route("/download")
def download():
    filename = request.args.get("file")
    return send_from_directory("/app/static", filename)  # 仍可能 ../../

# ✅ 较安全 — 使用 safe_join
from werkzeug.utils import safe_join
filepath = safe_join("/app/static", filename)  # 阻止目录遍历
```

## FastAPI 特定检测

```python
# ❌ 危险
@app.get("/files/{filepath:path}")
async def get_file(filepath: str):
    return FileResponse(f"/app/data/{filepath}")  # path 类型可包含 /

# ❌ 危险 — UploadFile 下载
@app.get("/download")
async def download(filename: str):
    file = open(f"/app/uploads/{filename}", "rb")
    return StreamingResponse(file)
```

## 路径遍历绕过技巧检测

检查代码是否防护了以下绕过：
```python
# 简单校验（可被绕过）
filename = filename.replace("../", "")     # 绕过: ....// 
filename = filename.replace("..", "")       # 绕过: ..../
os.path.basename(user_path)                 # 绕过: ../../etc/passwd\x00.txt (null byte)

# 路径规范化
resolved = os.path.realpath(user_path)
if not resolved.startswith("/allowed/prefix"):
    raise ValueError("Path traversal detected")
```

## Sanitizer 检查

```python
# ✅ 有效防护
safe_join(base_dir, user_filename)         # Werkzeug
os.path.basename(user_path) + 白名单扩展名   # 基线安全
Path(user_path).resolve() + 前缀白名单       # Python 3.6+

# ⚠️ 不充分的防护
filename.startswith("/safe/")              # 相对路径可绕过
user_path.strip("/")                       # 无作用
re.sub(r"[^a-zA-Z0-9.]", "", user_path)   # 可能导致功能失效
```

## 审计判断规则

1. **确认漏洞**: 用户控制的路径进入文件读取函数，无路径验证
2. **路径注入**: 固定前缀路径 + 用户输入（`"/static/" + user_path`）
3. **误报**: 使用 safe_join 或 basename + 白名单
4. **高危目标文件**: `/etc/passwd`, `.env`, `settings.py`, `SECRET_KEY` 文件

## 风险评分

- **Critical (9-10)**: 可读取任意系统文件 (/etc/passwd, .env, SSH keys)
- **High (7-8)**: 可读取应用配置文件、源码
- **Medium (4-6)**: 目录受限但可读取上传文件/日志
- **Low (1-3)**: 只能读取特定类型文件（如 .txt）
