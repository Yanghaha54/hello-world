# Deserialization Detection Skill

## 检测能力

针对 Python Web 项目检测不安全的反序列化漏洞。

## 危险函数清单

```python
# ❌ CRITICAL — Pickle (任意代码执行)
pickle.load(user_file)
pickle.loads(user_data)
cPickle.loads(user_data)  # Python 2

# ❌ CRITICAL — PyYAML unsafe load
yaml.load(user_data)                      # 无 SafeLoader
yaml.load(user_data, Loader=yaml.Loader)  # 显式指定 unsafe Loader
yaml.full_load(user_data)                 # FullLoader 也不安全

# ❌ CRITICAL — Marshal
marshal.loads(user_data)

# ❌ CRITICAL — Dill (比 pickle 更危险)
dill.loads(user_data)

# ❌ HIGH — JSONPickle
jsonpickle.decode(user_data)
jsonpickle.loads(user_data)

# ❌ HIGH — Shelve (底层使用 pickle)
shelve.open(user_path)

# ❌ HIGH — PyTorch (模型文件使用 pickle)
torch.load(user_model_path)
torch.jit.load(user_model_path)

# ⚠️ MEDIUM — joblib
joblib.load(user_file)  # 默认使用 pickle
```

## 框架特定检测

### Django
```python
# ❌ 危险 — Session 反序列化（旧版 Cookie 签名 Session）
# Django < 1.6 使用 pickle 序列化 session
# 如果 SECRET_KEY 泄露，可伪造 pickle payload

# ❌ 危险 — Cache
cache.set("key", user_data, timeout=300)
cached = cache.get("key")
pickle.loads(cached)  # 如果缓存后端使用了 pickle

# ❌ 危险 — Celery
# Celery 默认使用 pickle 序列化任务
@app.task
def process(user_input):
    ...
```

### Flask
```python
# ❌ 危险 — Session (如果使用 pickle serializer)
from flask import Flask
app = Flask(__name__)
app.config["SESSION_SERIALIZER"] = "pickle"  # 危险！

# ❌ 危险 — Cookie 中的签名 pickle
# 如果 secret_key 泄露
```

### FastAPI
```python
# ❌ 危险 — 接收 pickle 数据
@app.post("/upload-model")
async def upload(file: UploadFile):
    model = pickle.loads(await file.read())  # CRITICAL
```

## 常见的"看起来安全"但危险的模式

```python
# ⚠️ 以为安全但危险
import yaml
data = yaml.safe_load(user_input)  # ✅ 安全
data = yaml.load(user_input)       # ❌ 危险！

# ⚠️ 容易混淆
# yaml.load  vs  yaml.safe_load
# pickle.load  vs  json.load (json 是安全的)
```

## Sanitizer 检测

Python 反序列化漏洞**无法有效 sanitize**，唯一的修复方式：
1. 不使用 pickle/yaml.load 处理用户数据
2. 使用 JSON 替代 pickle
3. 使用 yaml.safe_load 替代 yaml.load
4. 使用 HMAC 签名 + 严格密钥管理

## 审计判断规则

1. **确认漏洞**: pickle.loads(用户输入) — 直接确认，无需额外条件
2. **条件漏洞**: yaml.load(用户输入) — 可能被使用 SafeLoader
3. **误报**: 
   - 使用 safe_load 而非 load
   - 输入来自内部可信源（非外部用户）
   - 虽使用 pickle 但数据有 HMAC 签名保护

## 风险评分

- **Critical (9-10)**: pickle.loads(用户可控数据)
- **High (7-8)**: yaml.load(用户可控数据) 或 JSONPickle
- **Medium (4-6)**: 理论上可控但需要绕过其他防护
- **组合风险**: 文件上传 + pickle（上传恶意模型） → RCE
