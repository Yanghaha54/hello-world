# Information Leak Detection Skill

## 检测能力

针对 Python Web 项目检测敏感信息泄露漏洞。

## Django 检测

### DEBUG 模式
```python
# ❌ 危险 — 生产环境 DEBUG=True
# settings.py
DEBUG = True  # 详细错误页面暴露代码、配置、变量值

# ❌ 危险 — 条件 DEBUG
DEBUG = os.environ.get("DJANGO_DEBUG", "True") == "True"  # 默认 True

# 检查: settings.py, production.py, 环境变量
```

### SECRET_KEY 泄露
```python
# ❌ 危险 — 硬编码 SECRET_KEY
SECRET_KEY = "django-insecure-abc123..."  # 不应硬编码

# ❌ 危险 — SECRET_KEY 提交到 Git
# 检查 .gitignore 是否包含 settings.py

# ❌ 危险 — 弱 SECRET_KEY
SECRET_KEY = "my-secret-key"  # 太短/太简单
```

### 数据库凭证
```python
# ❌ 危险 — 硬编码数据库密码
DATABASES = {
    "default": {
        "PASSWORD": "mypassword123",  # 不应硬编码
    }
}

# ❌ 危险 — 配置文件中的 API Key
STRIPE_API_KEY = "sk_live_abc123..."
AWS_SECRET_ACCESS_KEY = "..."
```

### 管理页面暴露
```python
# ❌ 危险 — Django Admin 未加固
# url.py
urlpatterns = [
    path("admin/", admin.site.urls),  # 默认路径可被扫描
]

# ✅ 安全
path("f8a3c2-management/", admin.site.urls),  # 自定义难猜的路径
```

## Flask 检测

### Debug 模式
```python
# ❌ 危险
app.run(debug=True)
app.debug = True
app.config["DEBUG"] = True

# ❌ 危险 — debug 工具栏暴露
from flask_debugtoolbar import DebugToolbarExtension
toolbar = DebugToolbarExtension(app)  # 生产环境不应启用

# ❌ 危险 — Werkzeug debugger PIN
# 生产环境可访问 /console 需要 PIN，但 PIN 生成算法公开
```

### Secret Key
```python
# ❌ 危险 — 弱 secret_key
app.secret_key = "dev"
app.config["SECRET_KEY"] = "my-secret"

# ❌ 危险 — 默认 secret_key
app = Flask(__name__)  # 使用 __name__ 作为 secret_key（不安全）
```

## FastAPI 检测

```python
# ❌ 危险 — debug 模式
app = FastAPI(debug=True)

# ❌ 危险 — 错误详情暴露
@app.exception_handler(Exception)
async def debug_handler(request, exc):
    return JSONResponse(
        status_code=500,
        content={"error": str(exc), "traceback": traceback.format_exc()}
    )

# ❌ 危险 — OpenAPI/Swagger 暴露
app = FastAPI(docs_url="/docs")  # API 文档公开可访问
```

## 通用信息泄露

### 错误信息泄露
```python
# ❌ 危险 — 详细错误信息
try:
    ...
except Exception as e:
    return {"error": str(e), "details": repr(e)}  # 泄露内部信息

# ❌ 危险 — traceback 返回给用户
import traceback
return HttpResponse(traceback.format_exc())

# ✅ 安全
try:
    ...
except Exception:
    logger.exception("Error occurred")
    return {"error": "Internal server error"}
```

### 版本信息泄露
```python
# ❌ 危险 — 响应头暴露版本
# Server: gunicorn/20.0.4
# X-Powered-By: Flask/2.3.0

# ❌ 危险 — 依赖版本文件暴露
# requirements.txt 中精确版本可被用于已知漏洞扫描
```

### 日志泄露
```python
# ❌ 危险 — 日志中包含敏感数据
logger.info(f"User {email} login with password: {password}")
logger.debug(f"Full request: {request.body}")

# ❌ 危险 — logs 目录可访问
# /var/log/app/ 配置为 web 可访问
```

### 用户枚举
```python
# ❌ 危险 — 不同错误信息导致用户名枚举
# "Invalid password" vs "User not found"
if not user:
    return {"error": "User not found"}  # 暴露用户是否存在
elif not check_password(password, user.password):
    return {"error": "Invalid password"}  # 用户名存在但密码错误

# ✅ 安全 — 统一错误信息
if not user or not check_password(password, user.password):
    return {"error": "Invalid credentials"}
```

## 审计判断规则

1. **确认漏洞**: 
   - 生产环境 DEBUG=True
   - SECRET_KEY/API_KEY/密码 硬编码
   - 详细错误信息暴露给用户
   - 管理后台公开可访问
2. **需要复核**: 条件性 DEBUG（可能只在某些环境）
3. **误报**: 通过环境变量/Secrets Manager 注入的配置
4. **Git 历史检查**: 敏感数据可能在 Git 历史中

## 风险评分

- **High (7-8)**: SECRET_KEY 泄露、生产环境 DEBUG=True
- **Medium (4-6)**: 详细错误信息、用户枚举、版本泄露
- **Low (1-3)**: 非关键配置暴露、管理员路径可猜测
- **组合风险**: 信息泄露 + 其他漏洞 → 升级严重程度
