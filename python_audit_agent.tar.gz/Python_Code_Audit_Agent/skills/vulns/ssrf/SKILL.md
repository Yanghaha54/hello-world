# SSRF Detection Skill

## 检测能力

针对 Python Web 项目检测服务器端请求伪造 (SSRF) 漏洞。

## 危险函数清单

```python
# ❌ HIGH — requests 库
requests.get(user_url)
requests.post(user_url, data=payload)
requests.request("GET", user_url)
session = requests.Session()
session.get(user_url)

# ❌ HIGH — urllib
urllib.request.urlopen(user_url)
urllib.request.urlretrieve(user_url, local_path)
urllib.request.Request(user_url)

# ❌ HIGH — httpx
httpx.get(user_url)
httpx.AsyncClient().get(user_url)

# ❌ HIGH — aiohttp
async with aiohttp.ClientSession() as session:
    async with session.get(user_url) as resp:
        ...

# ⚠️ MEDIUM — 其他网络库
socket.create_connection((user_host, user_port))
ftplib.FTP(user_host)
smtplib.SMTP(user_host)
```

## 框架特定检测

### Django
```python
# ❌ 危险
def fetch_url(request):
    url = request.GET.get("url")
    resp = requests.get(url)
    return HttpResponse(resp.text)

def webhook_callback(request):
    url = request.POST.get("callback_url")
    requests.post(url, json={"status": "ok"})
```

### Flask
```python
# ❌ 危险
@app.route("/proxy")
def proxy():
    url = request.args.get("url")
    return requests.get(url).text
```

### FastAPI
```python
# ❌ 危险
@app.get("/fetch")
async def fetch(url: str = Query()):
    async with httpx.AsyncClient() as client:
        return await client.get(url)
```

## 常见防御与绕过

### URL 验证（可能被绕过）
```python
# ❌ 不充分的校验
if url.startswith("https://"):  # 可用 http://evil.com#https:// 绕过
    requests.get(url)

# ❌ 黑名单
blocked = ["localhost", "127.0.0.1", "192.168."]
if not any(b in url for b in blocked):  # 可用 127.0.0.1.xip.io 绕过
    requests.get(url)

# ✅ 较安全的做法
from urllib.parse import urlparse
parsed = urlparse(url)
if parsed.hostname not in ALLOWED_HOSTS:
    raise ValueError("Blocked")

# ✅ 使用代理/沙箱
# 将所有外部请求通过加固的代理发出
```

### DNS Rebinding 风险
即使做了 hostname 校验，也可能受到 DNS rebinding 攻击（TOCTOU）

## 审计判断规则

1. **确认漏洞**: URL 完全由用户控制且无有效校验
2. **受限 SSRF**: URL 部分可控（如只有 path 可控）
3. **盲 SSRF**: 发起请求但结果不返回给用户
4. **误报**: 
   - URL 来自配置文件/环境变量
   - 严格白名单校验 hostname
   - URL 只是内部硬编码

## 风险评分

- **Critical (9-10)**: 可访问内部云元数据 (169.254.169.254)、无任何限制
- **High (7-8)**: 可访问内网但有限制（只能 GET）
- **Medium (4-6)**: Blind SSRF、受限的 URL 控制
- **Low (1-3)**: 只有 path 可控且有限制

## 内网探测重点

关注是否有对以下目标的访问可能：
- `169.254.169.254` — AWS/阿里云/腾讯云 元数据
- `metadata.google.internal` — GCP 元数据
- `127.0.0.1` / `localhost` — 本地服务
- `10.0.0.0/8`, `172.16.0.0/12`, `192.168.0.0/16` — 内网
