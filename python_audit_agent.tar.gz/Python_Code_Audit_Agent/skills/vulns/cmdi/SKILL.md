# Command Injection Detection Skill

## 检测能力

针对 Python Web 项目检测命令注入漏洞。

## 危险函数清单

### Shell 执行

```python
# ❌ CRITICAL — 用户输入进入 shell
os.system(f"ping {user_host}")
os.popen(f"cat {user_file}")
commands.getoutput(f"ls {user_path}")  # Python 2

# ❌ CRITICAL — subprocess + shell=True
subprocess.call(f"ping {host}", shell=True)
subprocess.Popen(f"cat {file}", shell=True)
subprocess.run(f"ls {path}", shell=True)
subprocess.check_output(f"grep {pattern} {file}", shell=True)

# ⚠️ HIGH — subprocess 列表形式但可控参数
subprocess.call(["ping", user_host])  # 仍可注入 flags (e.g. -c 1; whoami)
subprocess.run(["git", "clone", user_repo_url])
```

### 代码执行

```python
# ❌ CRITICAL
eval(user_input)
exec(user_code)
exec(compile(user_input, "<string>", "exec"))

# ❌ HIGH
__import__(user_module_name)
importlib.import_module(user_module_name)
getattr(obj, user_attr_name)
setattr(obj, user_attr_name, user_value)
```

## 框架特定检测

### Django
```python
# ❌ 危险
def run_report(request):
    template = request.GET.get("template")
    os.system(f"generate_report --template {template}")

# ❌ 危险 — 动态导入
def load_plugin(request):
    plugin = request.GET.get("plugin")
    mod = __import__(f"plugins.{plugin}")
```

### Flask
```python
# ❌ 危险
@app.route("/exec")
def execute():
    cmd = request.args.get("cmd")
    return subprocess.check_output(cmd, shell=True)
```

### FastAPI
```python
# ❌ 危险
@app.get("/run")
async def run(command: str = Query()):
    proc = await asyncio.create_subprocess_shell(command)
```

## Sanitizer 检测

检查是否使用了以下安全措施：
```python
# ✅ 安全措施
shlex.quote(user_input)           # Shell 转义
subprocess.run(["cmd", arg1])      # 列表形式 + shell=False
# 白名单校验命令参数
ALLOWED_COMMANDS = ["status", "list"]
if user_cmd in ALLOWED_COMMANDS:
    ...
```

## 审计判断规则

1. **确认漏洞**: `shell=True` + 用户输入，或 `os.system()` + 用户输入
2. **参数注入**: 列表形式的命令中参数可控，可能注入 flags/options
3. **误报**: 使用 shlex.quote()、严格的字符串白名单、无用户输入
4. **eval/exec**: 只要参数来自用户输入即确认漏洞，无需额外条件

## 风险评分

- **Critical (9-10)**: 无过滤的命令注入 / eval(用户输入)
- **High (7-8)**: 受限制但可绕过的命令注入
- **Medium (4-6)**: 参数注入（不能执行任意命令但可改变行为）
- **组合风险**: CMDi + 内网可达 → 内网渗透，升级为 Critical
