# Authorization Bypass Detection Skill

## 检测能力

针对 Python Web 项目检测权限绕过和认证缺失漏洞。

## Django 检测要点

### 缺少认证装饰器
```python
# ❌ 危险 — 无 @login_required
def sensitive_view(request):
    user_data = get_user_data(request.user)
    return JsonResponse(user_data)

# ✅ 安全
@login_required
def sensitive_view(request):
    ...

# ❌ 危险 — 无 @permission_required
@login_required
def admin_view(request):
    all_users = User.objects.all()  # 普通用户不应访问
    return render(request, "admin.html", {"users": all_users})

# ✅ 安全
@permission_required("auth.view_user")
def admin_view(request):
    ...
```

### 类视图 (CBV)
```python
# ❌ 危险 — CBV 忘记加 LoginRequiredMixin
class AdminPanel(View):
    def get(self, request):
        ...

# ✅ 安全
class AdminPanel(LoginRequiredMixin, View):
    ...

# ❌ 危险 — Django REST Framework 无权限类
class UserViewSet(ModelViewSet):
    queryset = User.objects.all()  # 所有人可访问

# ✅ 安全
class UserViewSet(ModelViewSet):
    permission_classes = [IsAuthenticated]
```

### 对象级别权限缺失
```python
# ❌ 危险 — 未校验对象归属
def edit_document(request, doc_id):
    doc = Document.objects.get(id=doc_id)  # 任何登录用户可编辑
    doc.title = request.POST.get("title")
    doc.save()

# ✅ 安全
def edit_document(request, doc_id):
    doc = Document.objects.get(id=doc_id, owner=request.user)
```

### Middleware 绕过
```python
# ❌ 危险 — URL 排除不当
# 检查 settings.py 中 LOGIN_URL 排除

# ❌ 危险 — Internal IP 伪冒
# X-Forwarded-For 头可能被伪造
ip = request.META.get("HTTP_X_FORWARDED_FOR", request.META["REMOTE_ADDR"])
if ip in INTERNAL_IPS:  # 可能被绕过
```

## Flask 检测要点

### 缺少认证装饰器
```python
# ❌ 危险
@app.route("/admin")
def admin():
    return "Admin Panel"

# ✅ 安全 (使用 flask-login)
@app.route("/admin")
@login_required
def admin():
    ...

# ❌ 危险 — before_request 认证可能被绕过
@app.before_request
def check_auth():
    if request.endpoint not in ("login", "static"):
        if not current_user.is_authenticated:
            return redirect(url_for("login"))
# 如果忘记注册 endpoint 名称，可能绕过
```

### 手动 Session 校验不完整
```python
# ❌ 危险 — 只检查 session 存在但不验证
if "user_id" in session:
    # 允许访问 — 但 session 可能被伪造

# ✅ 安全 — 使用 flask-login 或类似库
```

## FastAPI 检测要点

### 缺少依赖注入
```python
# ❌ 危险
@app.get("/admin")
async def admin():
    return {"data": get_all_users()}  # 无认证

# ✅ 安全
@app.get("/admin")
async def admin(current_user: User = Depends(get_current_user)):
    ...

# ❌ 危险 — get_current_user 实现有缺陷
def get_current_user(token: str = Header()):
    try:
        payload = jwt.decode(token, SECRET, algorithms=["HS256"])
    except:
        return None  # ❌ 返回 None 但视图可能继续执行
```

### 越权访问 (IDOR)
```python
# ❌ 危险 — 不验证对象所有权
@app.get("/users/{user_id}/orders")
async def get_orders(user_id: int):
    return orders_db.get_by_user(user_id)

# 攻击者将 user_id 改为其他用户的 ID 即可越权
```

## 业务逻辑授权缺失

```python
# ❌ 危险 — 不校验订单状态
@app.post("/order/{order_id}/refund")
@login_required
def refund(order_id):
    order = Order.get(order_id)
    # 未校验 order.user_id == current_user.id
    process_refund(order)

# ❌ 危险 — 不校验操作权限
@app.post("/api/delete-user")
@login_required
def delete_user():
    user_id = request.form.get("user_id")
    # 普通用户不应该能删除其他用户
    User.delete(user_id)
```

## 审计判断规则

1. **确认漏洞**: 
   - 高危操作（删除、修改、查看敏感数据）无认证/授权
   - 对象操作不校验所有权
   - 角色/权限检查可被绕过
2. **需要复核**: 认证通过 middleware 实现，需确认覆盖范围
3. **误报**: 使用成熟认证库的正确用法

## 风险评分

- **Critical (9-10)**: 无需认证的管理功能、可操纵任意用户数据
- **High (7-8)**: 需认证但可越权访问其他用户数据
- **Medium (4-6)**: 低危操作的授权缺失
- **Low (1-3)**: 配置不当但影响有限
