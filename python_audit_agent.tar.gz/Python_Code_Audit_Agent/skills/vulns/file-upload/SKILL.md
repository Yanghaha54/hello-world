# File Upload Vulnerability Detection Skill

## 检测能力

针对 Python Web 项目检测文件上传漏洞。

## 危险模式

### 无类型/扩展名校验
```python
# ❌ 危险 — Django 无校验
def upload(request):
    file = request.FILES["file"]
    with open(f"/app/uploads/{file.name}", "wb") as f:
        f.write(file.read())

# ❌ 危险 — Flask 无校验
@app.route("/upload", methods=["POST"])
def upload():
    file = request.files["file"]
    file.save(f"/app/uploads/{secure_filename(file.filename)}")

# ❌ 危险 — FastAPI 无校验
@app.post("/upload")
async def upload(file: UploadFile):
    content = await file.read()
    with open(f"/app/uploads/{file.filename}", "wb") as f:
        f.write(content)
```

### 不充分的校验
```python
# ❌ 危险 — 只检查 Content-Type（可伪造）
if file.content_type in ALLOWED_TYPES:  # Content-Type 由客户端设置
    save_file(file)

# ❌ 危险 — 只检查扩展名黑名单
blocked = [".py", ".php", ".jsp"]
ext = os.path.splitext(file.name)[1]
if ext not in blocked:  # 可上传 .pyc, .pth, .htaccess
    save_file(file)

# ❌ 危险 — 可以双扩展名绕过
# file.php.jpg — 在 Apache 上可能被解析为 PHP

# ❌ 危险 — 大小写绕过
# file.PHP, file.Php, file.pHp
```

### Zip Slip (压缩包路径遍历)
```python
# ❌ 危险 — tar/zip 提取无验证
import tarfile
tar = tarfile.open(uploaded_tar)
tar.extractall(path="/app/uploads")  # 恶意压缩包 → 覆盖任意文件

import zipfile
with zipfile.ZipFile(uploaded_zip) as zf:
    zf.extractall("/app/uploads")
```

### Django 特定
```python
# ❌ 危险 — ImageField 但未校验内容
class Profile(models.Model):
    avatar = models.ImageField(upload_to="avatars/")

# ❌ 危险 — FileField 接受任意类型
class Document(models.Model):
    file = models.FileField(upload_to="docs/")
    # 攻击者可上传 .html → XSS
    # 攻击者可上传 .py  → 如果 upload_to 在 web 目录 → RCE

# ⚠️ 需检查 — MEDIA_URL 配置
# 如果 MEDIA_URL 在 web 目录且不做文件类型校验 → 危险
```

### Flask 特定
```python
# ❌ 危险 — secure_filename 只防止路径遍历，不限制类型
filename = secure_filename(file.filename)  # 仍可上传 .py 文件

# ❌ 危险 — 文件保存到 static 目录
file.save(os.path.join(app.static_folder, filename))  # 可访问执行
```

## 安全实践检查

```python
# ✅ 推荐做法

# 1. 白名单扩展名
ALLOWED_EXTENSIONS = {".jpg", ".png", ".pdf", ".docx"}
ext = os.path.splitext(file.filename)[1].lower()
if ext not in ALLOWED_EXTENSIONS:
    raise ValueError("File type not allowed")

# 2. 魔数校验
import magic
mime = magic.from_buffer(file.read(2048), mime=True)
if mime not in ALLOWED_MIMETYPES:
    raise ValueError("File type mismatch")

# 3. 文件名随机化
import uuid
safe_name = f"{uuid.uuid4()}{ext}"

# 4. 存储与 web 分离
# 上传文件不应保存在 web 可访问的目录

# 5. 大小限制
if file.size > MAX_UPLOAD_SIZE:
    raise ValueError("File too large")
```

## 审计判断规则

1. **确认漏洞**: 
   - 无任何类型校验
   - 校验可被绕过（只检查 Content-Type）
   - 文件保存在 web 可访问目录
2. **Zip Slip**: 压缩包提取无路径遍历防护
3. **组合风险**: 文件上传 + LFI → RCE
4. **误报**: 完整的白名单校验 + 魔数检测 + 文件隔离存储

## 风险评分

- **Critical (9-10)**: 可上传 .py/.php 到 web 目录 → RCE
- **High (7-8)**: 可上传 HTML → XSS / 任意类型到 web 可访问路径
- **Medium (4-6)**: 校验不充分但有部分防护 / 非 web 可访问目录
- **Low (1-3)**: 受限上传但理论上可绕过
