# SQL Injection Detection Skill

## 检测能力

针对 Python Web 项目检测 SQL 注入漏洞。

## Django 检测要点

### 危险模式 (RAW SQL)
```python
# ❌ 危险 — f-string 拼接
cursor.execute(f"SELECT * FROM users WHERE id={user_input}")
cursor.execute("SELECT * FROM users WHERE id=%s" % user_input)
cursor.execute("SELECT * FROM users WHERE id=" + user_input)

# ❌ 危险 — RawSQL
User.objects.filter(RawSQL(f"id = {user_input}"))

# ❌ 危险 — .raw()
User.objects.raw(f"SELECT * FROM users WHERE name={user_input}")

# ❌ 危险 — .extra()
User.objects.extra(where=[f"name='{user_input}'"])

# ✅ 安全 — ORM 参数化
User.objects.filter(id=user_input)
User.objects.filter(name__icontains=user_input)
```

### 检查点
1. `cursor.execute()` 是否使用了字符串拼接/f-string/%
2. `RawSQL()` 参数是否包含用户输入
3. `.raw()` / `.extra()` 的 SQL 是否拼接了用户输入
4. 是否使用了 `params` 参数化（安全）

## Flask / SQLAlchemy 检测要点

### 危险模式
```python
# ❌ 危险 — 字符串拼接
db.engine.execute(f"SELECT * FROM users WHERE id={user_input}")
db.session.execute(text(f"SELECT * FROM users WHERE id={user_input}"))

# ❌ 危险 — .exec_driver_sql()
db.session.exec_driver_sql(f"SELECT * FROM {table}")

# ✅ 安全 — SQLAlchemy ORM
User.query.filter_by(id=user_input)
db.select(User).where(User.id == user_input)
```

### 检查点
1. `text()` 的 SQL 是否包含用户输入
2. `execute()` 是否使用了参数绑定
3. 动态表名/列名是否来自用户输入

## FastAPI / SQLAlchemy 检测要点

```python
# ❌ 危险
session.execute(text(f"SELECT * FROM users WHERE id={user_input}"))
result = await session.execute(f"SELECT * FROM users WHERE name='{name}'")

# ✅ 安全
stmt = select(User).where(User.id == user_id)
result = await session.execute(stmt)
```

## 通用 Python SQL 检测

```python
# ❌ sqlite3
cursor.execute(f"SELECT * FROM users WHERE id={user_input}")
conn.execute("SELECT * FROM users WHERE id=" + user_input)

# ❌ psycopg2
cursor.execute(f"SELECT * FROM users WHERE name='{name}'")

# ❌ pymysql
cursor.execute("SELECT * FROM users WHERE id=%s" % user_input)
```

## 审计判断规则

1. **确认漏洞**: 用户输入经字符串拼接进入 SQL，且无有效 sanitizer
2. **可能误报**: 用户输入经过严格类型转换（int()）或白名单校验
3. **需要复核**: ORM raw/extra 方法使用了复杂动态构造
4. **安全**: 使用 ORM 参数化查询或 `cursor.execute(sql, params)` 形式

## 风险评分

- **Critical (9-10)**: 无需认证的 SQLi，可读取任意数据
- **High (7-8)**: 需认证但无权限隔离的 SQLi
- **Medium (4-6)**: 有限的 SQLi（类型受限、错误回显不完整）
- **Low (1-3)**: 极难利用的 SQLi（需要特定条件）
