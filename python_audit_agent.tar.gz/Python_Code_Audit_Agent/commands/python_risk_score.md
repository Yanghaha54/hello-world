# /python_risk_score — 快速风险评分命令

对项目进行快速风险评分，不做深度语义分析。适用于初步项目安全评估。

## 用法

```
/python_risk_score
```

## 参数

可选参数：
- `--path DIR` — 指定路径（默认当前目录）
- `--framework auto|django|flask|fastapi`
- `--summary-only` — 只输出摘要，不输出详细发现列表

## 执行流程

1. 项目发现 — 识别框架和扫描范围
2. 快速 AST 扫描 — 识别 Source 和 Sink 点
3. 风险计数 — 统计各类别的高风险函数调用数量
4. 不进入 LLM 深度分析阶段
5. 不进行数据流追踪
6. 不生成详细修复建议

## 输出

```
============================================
Python Code Security — Quick Risk Assessment
============================================

Project: /path/to/your/project
Framework: Django (detected)
Total .py files: 850
Scanned: 720 (130 skipped)

--- Risk Summary ---
Overall Risk Level: HIGH

High-Risk Function Calls Found:
  eval/exec: 12
  os.system/subprocess: 28
  raw SQL execute: 56
  pickle.loads: 5
  yaml.load (unsafe): 3
  mark_safe (potential XSS): 18
  requests with variable URL: 34

Risk by Module:
  api/views.py: 15 high-risk calls
  utils/tasks.py: 8 high-risk calls
  core/importer.py: 6 high-risk calls

Recommendation:
  Run /python_full_scan for detailed analysis.
```

## 使用场景

- 接手新项目时的快速安全评估
- CI/CD 中的快速门禁检查
- 定期安全巡检的快照
