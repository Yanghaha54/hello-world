# /python_full_scan — 全量扫描命令

对整个 Python Web 项目进行完整的安全审计，运行全部 6 阶段流水线。

## 用法

```
/python_full_scan
```

## 参数

可选参数：
- `--framework auto|django|flask|fastapi` — 强制指定框架类型（默认自动检测）
- `--batch-size N` — 每批处理的文件数（默认 50）
- `--output-dir DIR` — 报告输出目录（默认 ./reports）
- `--vuln-types sqli,xss,cmdi` — 只审计指定的漏洞类型（默认全部）
- `--skip-cve` — 跳过 CVE 依赖扫描

## 执行流程

### Phase 1: Indexing — 代码索引
- 遍历项目目录，排除 venv、tests 等非业务代码
- 对每个 .py 文件进行 AST 解析
- 提取函数签名、类定义、导入关系
- 构建 Call Graph 和模块依赖图
- 计算文件复杂度评分

### Phase 1.5: Endpoint Enumeration — 端点枚举
- 运行 endpoint_scanner.py 提取所有 HTTP 路由
- 识别所有外部接口（URL 路径 + HTTP 方法）
- 标注认证要求和路径参数
- 输出完整端点清单 `endpoints.json`

### Phase 2: Source/Sink Discovery — 风险点发现
- 根据 source-registry.md 匹配用户输入入口
- 根据 sink-registry.md 匹配危险函数调用
- 识别框架特定的安全机制
- 标记 Santizer（过滤函数）

### Phase 3: Dataflow — 数据流分析
- 追踪 Source → Sink 的数据流路径
- 检查路径上是否存在有效 Sanitizer
- 计算初始风险分数

### Phase 4: LLM Deep Audit — 深度审计
- Scan Agent + Audit Agent 协作
- 构建精准上下文窗口（端点感知）
- Claude 对每个风险点语义分析
- 跟踪审计覆盖率：记录哪些端点/文件已被审计
- 输出 confirmed_vulns.json + audit_coverage.json

### Phase 5: Review — 复核
- Review Agent 去重合并
- 误报识别和排除
- 关联分析（组合漏洞）
- 覆盖率质量审查：检查审计盲区

### Phase 6: Report — 报告生成
- Report Agent 生成结构化报告
- 输出 Markdown 格式
- 包含端点审计清单 + 覆盖率分析
- 包含修复建议和优先级路线图

## 输出

- `reports/audit-report-<timestamp>.md` — 完整审计报告（含端点清单 + 覆盖率分析）
- `reports/audit-data/endpoints.json` — 外部接口清单
- `reports/audit-data/audit_coverage.json` — 审计覆盖率数据
- `reports/audit-data/` — 其他中间数据（index.json, risk_entries.json 等）

## 性能参考

| 代码规模 | 预计耗时 |
|---------|---------|
| 1-5 MB  | 5-15 分钟 |
| 5-15 MB | 15-45 分钟 |
| 15-50 MB | 45-120 分钟 |

实际耗时取决于文件数量、复杂度和发现的风险点数量。
