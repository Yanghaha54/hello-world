# /python_audit — 定向审计命令

对指定路径进行定向安全审计。

## 用法

```
/python_audit <target_path>
```

## 参数

- `target_path` (必需): 要审计的文件或目录路径
- 可以是单个 .py 文件、目录路径或包名
- 支持相对路径和绝对路径

## 执行流程

1. 当前工作目录必须是 Python Web 项目根目录
2. 启动 **Scan Agent** (`agents/scan-agent.md`) 扫描指定路径
3. 启动 **Audit Agent** (`agents/audit-agent.md`) 深度分析
4. 启动 **Review Agent** (`agents/review-agent.md`) 复核
5. 启动 **Report Agent** (`agents/report-agent.md`) 生成审计报告

## 示例

```
/python_audit api/views.py                    # 审计单个文件
/python_audit api/                            # 审计整个 api 目录
/python_audit utils/helpers.py:42-100         # 审计文件的特定行范围
```

## 输出

- `reports/audit-report-<timestamp>.md` — 审计报告

## 注意事项

- 定向审计只扫描指定路径及其直接依赖
- 不会扫描 `config/scan-config.yaml` 中配置的 exclude 目录
- 大文件（> 5000 行）会被自动分块处理
