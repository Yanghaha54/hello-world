#!/bin/bash
# Python Code Audit Agent — 环境初始化脚本

set -e

echo "============================================"
echo "Python Code Audit Agent — Setup"
echo "============================================"

# 检查 Python 版本
echo "[1/4] Checking Python version..."
python3 --version
PYTHON_VERSION=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
if [[ "$PYTHON_VERSION" < "3.10" ]]; then
    echo "ERROR: Python 3.10+ required, found $PYTHON_VERSION"
    exit 1
fi
echo "  Python $PYTHON_VERSION — OK"

# 安装依赖
echo "[2/4] Installing Python dependencies..."
pip3 install -q bandit safety astor radon 2>/dev/null || echo "  Warning: some optional deps failed, continuing..."

# 验证项目结构
echo "[3/4] Verifying project structure..."
REQUIRED_DIRS=(
    "agents"
    "commands"
    "skills/code-scanner/scripts"
    "skills/code-scanner/references"
    "skills/vulns/sqli"
    "skills/vulns/xss"
    "skills/vulns/cmdi"
    "skills/vulns/ssrf"
    "skills/vulns/deserialize"
    "skills/vulns/authz"
    "skills/vulns/file-read"
    "skills/vulns/file-upload"
    "skills/vulns/info-leak"
    "skills/vulns/xxe"
    "skills/vulns/cve-scanner"
    "skills/report-generator/assets"
    "config"
    "tests/fixtures"
)

for dir in "${REQUIRED_DIRS[@]}"; do
    if [ -d "$dir" ]; then
        echo "  $dir/ — OK"
    else
        echo "  $dir/ — MISSING (creating...)"
        mkdir -p "$dir"
    fi
done

# 验证关键文件
echo "[4/4] Verifying key files..."
REQUIRED_FILES=(
    "CLAUDE.md"
    "DESIGN.md"
    "config/risk-weights.yaml"
    "config/scan-config.yaml"
    "skills/code-scanner/scripts/endpoint_scanner.py"
    "skills/code-scanner/references/route-patterns.md"
)

for file in "${REQUIRED_FILES[@]}"; do
    if [ -f "$file" ]; then
        echo "  $file — OK"
    else
        echo "  $file — MISSING"
    fi
done

echo ""
echo "============================================"
echo "Setup complete!"
echo ""
echo "Commands:"
echo "  /python_audit <path>   — Targeted audit"
echo "  /python_full_scan       — Full project scan"
echo "  /python_risk_score      — Quick risk scoring"
echo "============================================"
